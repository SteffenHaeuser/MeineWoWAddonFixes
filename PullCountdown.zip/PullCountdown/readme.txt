﻿== To use PullCountdown with a button ==

1. Bring up the macro interface with /macro
2. Select a macro icon and name of your choice.
3. In the enter macro commands editbox type:

/run PullCountdown.Pull(x)

X is the countdown timer. (omitting x defaults to 3)

To abort a pull before the countdown finishes 
click the button again.