BasicThreatBar = LibStub("AceAddon-3.0"):NewAddon("BasicThreatBar", "AceConsole-3.0", "AceEvent-3.0")
local self = BasicThreatBar
local UPDATEPERIOD, elapsed = .25, 0

local L = LibStub("AceLocale-3.0"):GetLocale("BasicThreatBar")
local LSM = LibStub("LibSharedMedia-3.0")

--Register some additional Blizzard bar textures
LSM:Register("statusbar", "Blizzard2", "Interface\\TARGETINGFRAME\\UI-TargetingFrame-Barfill")
LSM:Register("statusbar", "Blizzard3", "Interface\\RAIDFRAME\\Raid-Bar-Hp-Fill")
LSM:Register("statusbar", "Blizzard4", "Interface\\TARGETINGFRAME\\BarFill2")
LSM:Register("statusbar", "Blizzard5", "Interface\\RAIDFRAME\\Raid-Bar-Resource-Fill")
LSM:Register("statusbar", "Blizzard Archeology", "Interface\\Archeology\\Arch-Progress-Fill")
	


local threatbar = CreateFrame("StatusBar", "ThreatBar", UIParent, BackdropTemplateMixin and "BackdropTemplate")

threatbar:SetMovable(true)
threatbar:SetResizable(true)
threatbar:SetClampedToScreen( true )
threatbar:RegisterForDrag("LeftButton");


local function GetPosition()
local point, _, relativePoint, xOfs, yOfs = threatbar:GetPoint()
	self.db.profile.point = point
	self.db.profile.relativePoint = relativePoint
	self.db.profile.xOfs = xOfs
	self.db.profile.yOfs = yOfs
end

threatbar:SetScript("OnDragStart", function(s) 
	if not UnitAffectingCombat("player") then
		s:StartMoving()
	end
end)
threatbar:SetScript("OnDragStop", function(s) 
s:StopMovingOrSizing()
GetPosition()
end)

threatbar:SetMinMaxValues(0, 100)
threatbar:SetValue(0)

local function SetOrientation()
	if self.db.profile.vertical then
		threatbar:SetOrientation("VERTICAL")
		threatbar:SetRotatesTexture(true)
	else
		threatbar:SetOrientation("HORIZONTAL")
		threatbar:SetRotatesTexture(false)
	end
end


-- border frame
local borderframe = CreateFrame("Frame", "BorderFrame", ThreatBar, BackdropTemplateMixin and "BackdropTemplate")
borderframe:SetPoint("TOPLEFT", ThreatBar, "TOPLEFT", -2, 2)
borderframe:SetPoint("BOTTOMRIGHT", ThreatBar, "BOTTOMRIGHT", 2, -2)


local function SetBorder()
borderframe:SetBackdrop( { 
  bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background", 
  edgeFile = LSM:Fetch("border", self.db.profile.border), tile = 1, tileSize = 10, edgeSize = 10, 
  insets = { left = 0, right = 0, top = 0, bottom = 0 }
});
borderframe:SetBackdropColor(0,0,0,0);
borderframe:SetBackdropBorderColor(self.db.profile.borderRed, self.db.profile.borderGreen, self.db.profile.borderBlue, self.db.profile.borderAlpha)
end



local font1 = borderframe:CreateFontString("UnitName", "OVERLAY", "GameFontWhite")

local function SetNamePoint()
	font1:ClearAllPoints()
	if not font1:IsVisible() then
		font1:Show()
	end
	if self.db.profile.NamePoint == "BOTTOMLEFT" or self.db.profile.NamePoint == "BOTTOMRIGHT" or self.db.profile.NamePoint == "BOTTOM" then
		font1:SetPoint(self.db.profile.NamePoint, threatbar, self.db.profile.NamePoint, 0, -(2 + self.db.profile.fontsize))
	elseif self.db.profile.NamePoint == "LEFT" or self.db.profile.NamePoint == "RIGHT" or self.db.profile.NamePoint == "CENTER" then
		font1:SetPoint(self.db.profile.NamePoint, threatbar, self.db.profile.NamePoint, 0, 0)
	elseif self.db.profile.NamePoint == "TOPLEFT" or self.db.profile.NamePoint == "TOPRIGHT" or self.db.profile.NamePoint == "TOP" then
		font1:SetPoint(self.db.profile.NamePoint, threatbar, self.db.profile.NamePoint, 0, (2 + self.db.profile.fontsize))
	elseif self.db.profile.NamePoint == "Left Outside" then
		font1:SetPoint("RIGHT", threatbar, "LEFT", 0, 0)
	elseif self.db.profile.NamePoint == "Right Outside" then
		font1:SetPoint("LEFT", threatbar, "RIGHT", 0, 0)
	else
		font1:Hide()
	end
end

local font2 = borderframe:CreateFontString("Percent", "OVERLAY", "GameFontWhite")

local function SetThreatPoint()
	font2:ClearAllPoints()
	if not font2:IsVisible() then
		font2:Show()
	end
	if self.db.profile.ThreatPoint == "BOTTOMLEFT" or self.db.profile.ThreatPoint == "BOTTOMRIGHT" or self.db.profile.ThreatPoint == "BOTTOM" then
		font2:SetPoint(self.db.profile.ThreatPoint, threatbar, self.db.profile.ThreatPoint, 0, -(2 + self.db.profile.fontsize))
	elseif self.db.profile.ThreatPoint == "TOPLEFT" or self.db.profile.ThreatPoint == "TOPRIGHT" or self.db.profile.ThreatPoint == "TOP" then
		font2:SetPoint(self.db.profile.ThreatPoint, threatbar, self.db.profile.ThreatPoint, 0, (2 + self.db.profile.fontsize))
	elseif self.db.profile.ThreatPoint == "LEFT" or self.db.profile.ThreatPoint == "RIGHT" or self.db.profile.ThreatPoint == "CENTER" then
		font2:SetPoint(self.db.profile.ThreatPoint, threatbar, self.db.profile.ThreatPoint, 0, 0)
	elseif self.db.profile.ThreatPoint == "Left Outside" then
		font2:SetPoint("RIGHT", threatbar, "LEFT", 0, 0)
	elseif self.db.profile.ThreatPoint == "Right Outside" then
		font2:SetPoint("LEFT", threatbar, "RIGHT", 0, 0)	
	else
		font2:Hide()
	end
end


--local icon = threatbar:CreateTexture("Icon", "OVERLAY")
--icon:SetTexture("Interface\\LFGFrame\\UI-LFG-ICON-PORTRAITROLES")
--icon:SetTexCoord(GetTexCoordsForRoleSmallCircle("TANK"))
--icon:SetPoint("TOPLEFT", threatbar, "TOPLEFT", 0, 15)
--icon:SetHeight(14)
--icon:SetWidth(14)
--icon:Hide()

local function SetFont()
local flags = {}
    if self.db.profile.outline then
        tinsert(flags, "OUTLINE")
    end
    if self.db.profile.monochrome then
        tinsert(flags, "OUTLINEMONOCHROME")
    end
    if self.db.profile.thickoutline then
        tinsert(flags, "THICKOUTLINE")
    end
font1:SetFont(LSM:Fetch("font", self.db.profile.font), self.db.profile.fontsize, table.concat(flags, ","))
font2:SetFont(LSM:Fetch("font", self.db.profile.font), self.db.profile.fontsize, table.concat(flags, ","))
end

local function SetTexture()
	threatbar:SetStatusBarTexture(LSM:Fetch("statusbar", self.db.profile.texture))
	threatbar:SetBackdrop({ 
	bgFile = LSM:Fetch("statusbar", self.db.profile.texture),
	insets = {left = 0, right = 0, top = 0, bottom = 0}
})
	threatbar:SetBackdropColor(self.db.profile.backdropRed, self.db.profile.backdropGreen, self.db.profile.backdropBlue, self.db.profile.backdropAlpha)
end

function BasicThreatBar:RefreshConfig()
	threatbar:ClearAllPoints()
	threatbar:SetHeight(self.db.profile.height)
	threatbar:SetWidth(self.db.profile.width)
	threatbar:SetPoint(self.db.profile.point, UIParent, self.db.profile.relativePoint, self.db.profile.xOfs, self.db.profile.yOfs)
	SetTexture()
	SetFont()
	SetNamePoint()
	SetThreatPoint()
	SetBorder()
	SetOrientation()
	font2:SetTextColor(self.db.profile.red, self.db.profile.green, self.db.profile.blue, 1)
	threatbar:SetFrameStrata(self.db.profile.strata)
		
	if not self.db.profile.hidden then
		threatbar:Show()
		threatbar:EnableMouse(true)
	else
		threatbar:Hide()
		threatbar:EnableMouse(false)
	end

end

local TextPosition = {
	["TOPLEFT"] = L["Top Left"],
	["TOP"] = L["Top"],
	["TOPRIGHT"] = L["Top Right"],
	["BOTTOMLEFT"] = L["Bottom Left"],
	["BOTTOMRIGHT"] = L["Bottom Right"],
	["BOTTOM"] = L["Bottom"],
	["LEFT"] = L["Left Inside"],
	["RIGHT"] = L["Right Inside"],
	["CENTER"] = L["Center"],
	["None"] = L["None"],
	["Left Outside"] = L["Left Outside"],
	["Right Outside"] = L["Right Outside"],
} 

local defaults = {
  profile = {
    hidden = false, 
	font = "Friz Quadrata TT",
	texture = "Blizzard", 
	fontsize = 12, 
	point = "CENTER", 
	relativePoint = "CENTER", 
	xOfs = 0, 
	yOfs = 0, 
	height = 30, 
	width = 200, 
	outline = false, 
	monochrome = false, 
	thickoutline = false, 
	red = 1, 
	green = 1, 
	blue = 1, 
	NamePoint = "TOP",
	ThreatPoint = "CENTER",
	border = "None",
	borderRed = 1,
	borderGreen = 1,
	borderBlue = 1,
	borderAlpha = 1,
	percent = false,
	solo = false,
	petcolor = false,
	petr = .5,
	petg = .5,
	petb = .5,
	vertical = false,
	strata = "MEDIUM",
	status0Red = .1,
	status0Green = 1,
	status0Blue = .1,
	status0Alpha = 1,
	status1Red = 1,
	status1Green = 1,
	status1Blue = 0,
	status1Alpha = 1,
	status2Red = 1,
	status2Green = .5,
	status2Blue = .25,
	status2Alpha = 1,
	status3Red = 1,
	status3Green = .1,
	status3Blue = .1,
	status3Alpha = 1,
	status2depletedRed = 1,
	status2depletedGreen = .5,
	status2depletedBlue = .25,
	status2depletedAlpha = .5,
	status3depletedRed = 1,
	status3depletedGreen = .1,
	status3depletedBlue = .1,
	status3depletedAlpha = .5,
	backdropRed = 0,
	backdropGreen = 0,
	backdropBlue = 0,
	backdropAlpha = .5,
	tempthreatRed = .5,
	tempthreatGreen = .5,
	tempthreatBlue = 1,
	tempthreatAlpha = 1,
  }
}

local options = {
    name = "BasicThreatBar",
    type = 'group',
	args = {
		general = {
			order = 1,
			name = "General",
			type = 'group',
			args = {
				Hide = {
				name = L["Hide/Lock bar"],
				desc = L["Hide the bar when not in combat and lock it in place"],
				type = 'toggle',
				order = 1,
				set = function(info, key)
					self.db.profile.hidden = key
					if self.db.profile.hidden then
					threatbar:Hide()
					threatbar:EnableMouse(false)
					else
					threatbar:Show()
					threatbar:EnableMouse(true)
					end
				end,
				get = function(info)
					return self.db.profile.hidden
				end,
				},
			Solo = {
				name = L["Disable when solo"],
				desc = L["Disable the bar when not in a group and no pet is active"],
				type = 'toggle',
				order = 2,
				set = function(info, key)
					self.db.profile.solo = key
				end,
				get = function(info)
					return self.db.profile.solo
				end,
				},
		demo = {
			order = 3,
			type = 'execute',
			name = L["Test"],
			desc = L["Display sample text and value on the threat bar."],
			func = function()
					--if font1:GetText() and font2:GetText() then
					--font1:SetText("")
					--font2:SetText("")
					--threatbar:SetValue(0)
					--else
					font1:SetText(L["Sample"])
					if not self.db.profile.percent then
						font2:SetText("50K | 75%")
					else
						font2:SetText("75%")
					end
					threatbar:SetValue(75)
					threatbar:SetStatusBarColor(self.db.profile.status0Red, self.db.profile.status0Green, self.db.profile.status0Blue, self.db.profile.status0Alpha)
					--end
				end,
		},
		Border = {
		name = L["Border"],
		type = 'group',
		inline = true,
		order = 4,
		args = {
		Borders = {
            type = 'select',
            name = L["Borders"],
            desc = L["Change the bar's border"],
			order = 1,
            set = function(info,key)
			self.db.profile.border = key -- saves our new selection to the current one
			SetBorder()
			end,
            get = function()
			return self.db.profile.border -- variable that is my current selection
			end,
			dialogControl = "LSM30_Border",
			values = LSM:HashTable("border"),
				},
		border_color = {
        		name = L["Border Color"],
        		desc = L["Changes the color of the border"],
        		type = "color",
				hasAlpha = true,
        		order = 2,
        		set = function(info, r, g, b ,a)
        		self.db.profile.borderRed, self.db.profile.borderGreen, self.db.profile.borderBlue, self.db.profile.borderAlpha = r, g, b, a
        		borderframe:SetBackdropBorderColor(self.db.profile.borderRed, self.db.profile.borderGreen, self.db.profile.borderBlue, self.db.profile.borderAlpha)
        		end,
                get = function(info)
                return self.db.profile.borderRed, self.db.profile.borderGreen, self.db.profile.borderBlue, self.db.profile.borderAlpha
                end,
        	},
		},
		},
		Text = {
		name = L["Text"],
		type = 'group',
		inline = true,
		order = 5,
		args = {
			Fonts = {
				type = 'select',
				name = L["Fonts"],
				desc = L["Change the font"],
				order = 1,
				set = function(info,key)
				self.db.profile.font = key -- saves our new selection to the current one
				SetFont()
				end,
				get = function()
				return self.db.profile.font -- variable that is my current selection
				end,
				dialogControl = "LSM30_Font",
				values = LSM:HashTable("font"),
			},
			fontSize = {
				type = 'range',
				name = L["Font size"],
				min = 8,
				max = 32,
				step = 1,
				order = 10,
				set = function(info,key)
				self.db.profile.fontsize = key -- saves our new selection to the current one
				SetFont()
				SetThreatPoint()
				SetNamePoint()
				end,
				get = function()
				return self.db.profile.fontsize -- variable that is my current selection
				end,
			},
			font_outline = {
        		name = L["Outline"],
        		desc = L["Adds outline to the font"],
        		type = "toggle",
        		order = 120,
        		set = function(info, key)
					self.db.profile.outline = key
					SetFont()
        		end,
                get = function(info)
                return self.db.profile.outline
                end,
        	},
			font_monochrome = {
        		name = L["Monochrome"],
        		desc = L["Sets the font to monochrome"],
        		type = "toggle",
        		order = 100,
        		set = function(info, key)
        			self.db.profile.monochrome = key
					SetFont()
        		end,
                get = function(info)
                return self.db.profile.monochrome
                end,
        	},
        	font_thickoutline = {
        		name = L["Thick Outline"],
        		desc = L["Adds a thick black outline to the font"],
        		type = "toggle",
        		order = 110,
        		set = function(info, key)
        		self.db.profile.thickoutline = key
        		SetFont()
        		end,
                get = function(info)
                return self.db.profile.thickoutline
                end,
        	},
			font_color = {
        		name = L["Threat text color"],
        		desc = L["Changes the color of the threat text"],
        		type = "color",
        		order = 90,
        		set = function(info, r, g, b)
        		self.db.profile.red, self.db.profile.green, self.db.profile.blue = r, g, b
        		font2:SetTextColor(self.db.profile.red, self.db.profile.green, self.db.profile.blue, 1)
        		end,
                get = function(info)
                return self.db.profile.red, self.db.profile.green, self.db.profile.blue
                end,
        	},
			Name_Position = {
				type = 'select',
				name = L["Name position"],
				desc = L["Change the alignment of the name text"],
				order = 130,
				set = function(info, key)
				self.db.profile.NamePoint = key -- saves our new selection to the current one
				SetNamePoint()
				end,
				get = function()
				return self.db.profile.NamePoint -- variable that is my current selection
				end,
				values = TextPosition,
			},
			Threat_Position = {
				type = 'select',
				name = L["Threat position"],
				desc = L["Change the alignment of the threat text"],
				order = 140,
				set = function(info, key)
				self.db.profile.ThreatPoint = key -- saves our new selection to the current one
				SetThreatPoint()
				end,
				get = function()
				return self.db.profile.ThreatPoint -- variable that is my current selection
				end,
				values = TextPosition,
			},
			percent_only = {
        		name = L["% only"],
        		desc = L["Display only threat % without value"],
        		type = "toggle",
        		order = 150,
        		set = function(info, key)
					self.db.profile.percent = key
        		end,
                get = function(info)
                return self.db.profile.percent
                end,
        	},
			pet_color = {
        		name = L["Class color pets"],
        		desc = L["Color pets by class"],
        		type = "toggle",
        		order = 160,
        		set = function(info, key)
					self.db.profile.petcolor = key
        		end,
                get = function(info)
                return self.db.profile.petcolor
                end,
        	},
			petname_color = {
        		name = L["Pet color"],
        		desc = L["Changes the color of pet names"],
        		type = "color",
        		order = 170,
        		set = function(info, r, g, b)
        		self.db.profile.petr, self.db.profile.petg, self.db.profile.petb = r, g, b
        		end,
                get = function(info)
                return self.db.profile.petr, self.db.profile.petg, self.db.profile.petb
                end,
        	},
		},
	},
	Bar = {
	name = L["Bar"],
    type = 'group',
	inline = true,
	order = 6,
    args = {
		Textures = {
            type = 'select',
            name = L["Textures"],
            desc = L["Change the bar texture"],
			order = 1,
            set = function(info,key)
			self.db.profile.texture = key -- saves our new selection to the current one
			SetTexture()
			end,
            get = function()
			return self.db.profile.texture -- variable that is my current selection
			end,
			dialogControl = "LSM30_Statusbar",
			values = LSM:HashTable("statusbar"),
				},
			Height = {
				type = 'range',
				name = L["Bar Height"],
				min = 10,
				max = 500,
				step = 1,
				order = 2,
				set = function(info,key)
				self.db.profile.height = key -- saves our new selection to the current one
				threatbar:SetHeight(self.db.profile.height)
				end,
				get = function()
				return self.db.profile.height -- variable that is my current selection
				end,
			},
			Width = {
				type = 'range',
				name = L["Bar Width"],
				min = 10,
				max = 500,
				step = 1,
				order = 3,
				set = function(info,key)
				self.db.profile.width = key -- saves our new selection to the current one
				threatbar:SetWidth(self.db.profile.width)
				end,
				get = function()
				return self.db.profile.width -- variable that is my current selection
				end,
			},
			Vertical = {
				name = L["Vertical bar"],
				desc = L["Changes the bar to fill vertically"],
				type = 'toggle',
				order = 4,
				set = function(info, key)
					self.db.profile.vertical = key
					SetOrientation()
				end,
				get = function(info)
					return self.db.profile.vertical
				end,
			},
			Strata = {
				type = 'select',
				name = L["Strata"],
				desc = L["Change the strata of the bar"],
				order = 5,
				set = function(info,key)
				self.db.profile.strata = key -- saves our new selection to the current one
				threatbar:SetFrameStrata(self.db.profile.strata)
				end,
				get = function()
				return self.db.profile.strata -- variable that is my current selection
				end,
				values ={
						["HIGH"] = L["High"],
						["MEDIUM"] = L["Medium"],
						["LOW"] = L["Low"],
						["BACKGROUND"] = L["Background"],
				},
			},
			status0_color = {
        		name = L["Low threat color"],
        		desc = L["Changes the color of the bar for low threat"],
        		type = "color",
				hasAlpha = true,
        		order = 6,
        		set = function(info, r, g, b ,a)
        		self.db.profile.status0Red, self.db.profile.status0Green, self.db.profile.status0Blue, self.db.profile.status0Alpha = r, g, b, a
        		end,
                get = function(info)
                return self.db.profile.status0Red, self.db.profile.status0Green, self.db.profile.status0Blue, self.db.profile.status0Alpha
                end,
        	},
			status1_color = {
        		name = L["High threat color"],
        		desc = L["Changes the color of the bar for high threat"],
        		type = "color",
				hasAlpha = true,
        		order = 7,
        		set = function(info, r, g, b ,a)
        		self.db.profile.status1Red, self.db.profile.status1Green, self.db.profile.status1Blue, self.db.profile.status1Alpha = r, g, b, a
        		end,
                get = function(info)
                return self.db.profile.status1Red, self.db.profile.status1Green, self.db.profile.status1Blue, self.db.profile.status1Alpha
                end,
        	},
			status2_color = {
        		name = L["Low aggro color"],
        		desc = L["Changes the color of the bar for low tanking threat"],
        		type = "color",
				hasAlpha = true,
        		order = 8,
        		set = function(info, r, g, b ,a)
        		self.db.profile.status2Red, self.db.profile.status2Green, self.db.profile.status2Blue, self.db.profile.status2Alpha = r, g, b, a
        		end,
                get = function(info)
                return self.db.profile.status2Red, self.db.profile.status2Green, self.db.profile.status2Blue, self.db.profile.status2Alpha
                end,
        	},
			status3_color = {
        		name = L["High aggro color"],
        		desc = L["Changes the color of the bar for high tanking threat"],
        		type = "color",
				hasAlpha = true,
        		order = 9,
        		set = function(info, r, g, b ,a)
        		self.db.profile.status3Red, self.db.profile.status3Green, self.db.profile.status3Blue, self.db.profile.status3Alpha = r, g, b, a
        		end,
                get = function(info)
                return self.db.profile.status3Red, self.db.profile.status3Green, self.db.profile.status3Blue, self.db.profile.status3Alpha
                end,
        	},
			status2depleted_color = {
        		name = L["Low aggro depleted color"],
        		desc = L["Changes the color of the empty portion of the bar for low aggro"],
        		type = "color",
				hasAlpha = true,
        		order = 10,
        		set = function(info, r, g, b ,a)
        		self.db.profile.status2depletedRed, self.db.profile.status2depletedGreen, self.db.profile.status2depletedBlue, self.db.profile.status2depletedAlpha = r, g, b, a
        		end,
                get = function(info)
                return self.db.profile.status2depletedRed, self.db.profile.status2depletedGreen, self.db.profile.status2depletedBlue, self.db.profile.status2depletedAlpha
                end,
        	},
			status3depleted_color = {
        		name = L["High aggro depleted color"],
        		desc = L["Changes the color of the empty portion of the bar for high aggro"],
        		type = "color",
				hasAlpha = true,
        		order = 11,
        		set = function(info, r, g, b ,a)
        		self.db.profile.status3depletedRed, self.db.profile.status3depletedGreen, self.db.profile.status3depletedBlue, self.db.profile.status3depletedAlpha = r, g, b, a
        		end,
                get = function(info)
                return self.db.profile.status3depletedRed, self.db.profile.status3depletedGreen, self.db.profile.status3depletedBlue, self.db.profile.status3depletedAlpha
                end,
        	},
			backdrop_color = {
        		name = L["Depleted color"],
        		desc = L["Changes the color of the empty portion of the bar for low and high threat"],
        		type = "color",
				hasAlpha = true,
        		order = 12,
        		set = function(info, r, g, b ,a)
        		self.db.profile.backdropRed, self.db.profile.backdropGreen, self.db.profile.backdropBlue, self.db.profile.backdropAlpha = r, g, b, a
				threatbar:SetBackdropColor(self.db.profile.backdropRed, self.db.profile.backdropGreen, self.db.profile.backdropBlue, self.db.profile.backdropAlpha)
        		end,
                get = function(info)
                return self.db.profile.backdropRed, self.db.profile.backdropGreen, self.db.profile.backdropBlue, self.db.profile.backdropAlpha
                end,
        	},
			tempthreat_color = {
        		name = L["Temp threat color"],
        		desc = L["Changes the color of the bar for temporary threat while under fade or mirror image"],
        		type = "color",
				hasAlpha = true,
        		order = 13,
        		set = function(info, r, g, b ,a)
        		self.db.profile.tempthreatRed, self.db.profile.tempthreatGreen, self.db.profile.tempthreatBlue, self.db.profile.tempthreatAlpha = r, g, b, a
        		end,
                get = function(info)
                return self.db.profile.tempthreatRed, self.db.profile.tempthreatGreen, self.db.profile.tempthreatBlue, self.db.profile.tempthreatAlpha
                end,
        	},
			
			},
		},
	},
		},
		},
}

function BasicThreatBar:OnInitialize()

	self.db = LibStub("AceDB-3.0"):New("BasicThreatBarDB", defaults)
	
	options.args.profile = LibStub("AceDBOptions-3.0"):GetOptionsTable(self.db)
	local AceConfig = LibStub("AceConfig-3.0")
	AceConfig:RegisterOptionsTable("BasicThreatBar", options, nil)
	self.optionsFrame = {}
	local AceConfigDialog = LibStub("AceConfigDialog-3.0")
	self.optionsFrame.Main = AceConfigDialog:AddToBlizOptions("BasicThreatBar", "BasicThreatBar", nil, "general")
	
	AceConfigDialog:AddToBlizOptions(
	    "BasicThreatBar", options.args.profile.name, "BasicThreatBar", "profile")
	
	self.db.RegisterCallback(self, "OnProfileChanged", "RefreshConfig")
	self.db.RegisterCallback(self, "OnProfileCopied", "RefreshConfig")
	self.db.RegisterCallback(self, "OnProfileReset", "RefreshConfig")
	
end

function BasicThreatBar:OnEnable()
BasicThreatBar:RefreshConfig()
BasicThreatBar:RegisterEvent("UNIT_THREAT_SITUATION_UPDATE")
BasicThreatBar:RegisterEvent("UNIT_THREAT_LIST_UPDATE")
BasicThreatBar:RegisterEvent("PLAYER_TARGET_CHANGED")
BasicThreatBar:RegisterEvent("GROUP_ROSTER_UPDATE")
BasicThreatBar:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
BasicThreatBar:RegisterEvent("UNIT_TARGET")
end

BasicThreatBar:RegisterChatCommand("btb", "Slashhandler")

function BasicThreatBar:Slashhandler(input)
	if (input=="show") then
		threatbar:Show()
		self.db.profile.hidden = nil
		threatbar:EnableMouse(true)
	elseif (input=="hide") then
		threatbar:Hide()
		self.db.profile.hidden = true
		threatbar:EnableMouse(false)
	elseif (input=="" or input =="help") then
		InterfaceOptionsFrame_OpenToCategory("BasicThreatBar")
		InterfaceOptionsFrame_OpenToCategory("BasicThreatBar") -- workaround for first call not working sometimes
	end
end

local function GetShortTV(v)
	if v < 1000 and v > -1000 then
		return floor(v)
	elseif v >= 1000000 then
		return format("%.1fM", v/1000000)
	elseif v >= 1000 or v <= -1000 then
		return format("%.1fK", v/1000)
	end
end

local fademiActive = fademiActive -- set values
local tempthreat = {}--tempthreat -- set values
local currenttarget = currenttarget -- set values

local function GetLastThreat(mobId)
local targetGUID = UnitGUID("target")
if UnitCanAttack("player", mobId) then
	tempthreat[UnitGUID(mobId)] = select(5, UnitDetailedThreatSituation("player", mobId))
	if targetGUID == UnitGUID(mobId) then
		currenttarget = tempthreat[UnitGUID(mobId)]
	end
end
end

local function StoreThreat()
	if IsInGroup() or IsInRaid() then
		if IsInRaid() then
			for i = 1, GetNumGroupMembers() do
				GetLastThreat("raidtarget"..i)
				GetLastThreat("raidpettarget"..i)
				GetLastThreat("raidtargettarget"..i)
				GetLastThreat("raidpettargettarget"..i)
			end
		else
			for i = 1, GetNumSubgroupMembers() do
				GetLastThreat("partytarget"..i)
				GetLastThreat("partypettarget"..i)
				GetLastThreat("partytargettarget"..i)
				GetLastThreat("partypettargettarget"..i)
			end
		end

	end
	GetLastThreat("target")
	GetLastThreat("pettarget")
	GetLastThreat("targettarget")
	GetLastThreat("focus")
	GetLastThreat("focustarget")
	GetLastThreat("mouseover")
	GetLastThreat("mouseovertarget")

end

local function GetThreat(unitId, mobId)
	local _, _, threatpct, _, _ = UnitDetailedThreatSituation(unitId, mobId)
	if not threatpct then threatpct = 0 end
	return floor(threatpct)
end

local function GetThreatStatus(unitId, mobId)
	local _,status,_,_, _ = UnitDetailedThreatSituation(unitId, mobId)
	return status
end

local function GetTank(unitId, mobId)
	local isTanking,_,_,_, _ = UnitDetailedThreatSituation(unitId, mobId)
	if not isTanking then isTanking = false end
	return isTanking
end

local function GetThreatValue(unitId, mobId)
	local _, _, _, _, threatvalue = UnitDetailedThreatSituation(unitId, mobId)
	--local areaid = GetCurrentMapAreaID()
	if not threatvalue then threatvalue = 0 end
	--if areaid == 824 then threatvalue = threatvalue * 10 end --Dragon Soul
	return threatvalue
end

local function GetClassColor(unit)
	local unitClass, englishClass, classID = UnitClass(unit)
	local classColor = (CUSTOM_CLASS_COLORS or RAID_CLASS_COLORS)[englishClass] 
	if not classColor then 
		classColor = {r = .5, g = .5, b = .5}
	end -- in case returns nil?
	if not UnitIsPlayer(unit) and not self.db.profile.petcolor then
		classColor = {r = self.db.profile.petr, g = self.db.profile.petg, b = self.db.profile.petb}
	end
	return classColor.r, classColor.g, classColor.b
end

local function UpdateDisplay()
	local status = nil
	local highUnit = nil
	local unitThreat = 0
	local highThreat = 0
	local tankName = nil
	local unitThreatValue = 0
	local playerThreatValue = 0
	local unitTanking = nil
	local unitTankingColorR, unitTankingColorG, unitTankingColorB = nil, nil, nil
	local highUnitColorR, highUnitColorG, highUnitColorB = nil, nil, nil
	local tempthreatpct = 0
	local threatdiff = 0
	local threatpct = 0
	
	
	if not status then
		font1:SetText("")
		font2:SetText("")
		--icon:Hide()
		threatbar:SetValue(0)
		threatbar:SetBackdropColor(self.db.profile.backdropRed, self.db.profile.backdropGreen, self.db.profile.backdropBlue, self.db.profile.backdropAlpha)
		if self.db.profile.hidden == true then -- hide frame
			threatbar:Hide()
		end
	end
	
	if self.db.profile.solo and not IsInGroup() and not IsInRaid() and not HasPetUI() then
		return
	end
	
	if not IsInGroup() and not IsInRaid() and UnitCanAttack("player", "target") and not(UnitIsDead("target") or UnitIsFriend("player", "target") or UnitPlayerControlled("target")) then --Solo Target			
		status = GetThreatStatus("player", "target")
		threatpct = GetThreat("player", "target")
		playerThreatValue = GetThreatValue("player", "target")
		if HasPetUI() then
			unitThreatValue = GetThreatValue("pet", "target")
			highThreat = GetThreat("pet", "target")
			highUnit = UnitName("pet")
			highUnitColorR, highUnitColorG, highUnitColorB = GetClassColor("pet")
			unitTanking = GetTank("pet", "target")
			if unitTanking == true then
				unitTankingColorR, unitTankingColorG, unitTankingColorB = GetClassColor("pet")
				tankName = UnitName("pet")
			end
		end
	elseif not IsInGroup() and not IsInRaid() and UnitCanAttack("player", "targettarget") and not (UnitCanAttack("player", "target") or UnitIsDead("targettarget") or UnitIsFriend("player", "targettarget") or UnitPlayerControlled("targettarget")) then --Solo Target of Target
		status = GetThreatStatus("player", "targettarget")
		threatpct = GetThreat("player", "targettarget")
		playerThreatValue = GetThreatValue("player", "targettarget")
		if HasPetUI() then
			unitThreatValue = GetThreatValue("pet", "targettarget")
			highThreat = GetThreat("pet", "targettarget")
			highUnit = UnitName("pet")
			highUnitColorR, highUnitColorG, highUnitColorB = GetClassColor("pet")
			unitTanking = GetTank("pet", "targettarget")
			if unitTanking == true then
				unitTankingColorR, unitTankingColorG, unitTankingColorB = GetClassColor("pet")
				tankName = UnitName("pet")
			end
		end
	elseif IsInRaid() and UnitCanAttack("player", "target") and not (UnitIsDead("target") or UnitIsFriend("player", "target") or UnitPlayerControlled("target")) then --Raid Target 
		status = GetThreatStatus("player", "target")
		threatpct = GetThreat("player", "target")
		playerThreatValue = GetThreatValue("player", "target")
		for i = 1, GetNumGroupMembers() do
		if not UnitIsUnit("player", "raid"..i) then
			unitThreat = GetThreat("raid"..i, "target") 	
				if unitThreat > highThreat then 
					highThreat = unitThreat	
					highUnit = UnitName("raid"..i)
					highUnitColorR, highUnitColorG, highUnitColorB = GetClassColor("raid"..i)
					unitThreatValue = GetThreatValue("raid"..i, "target")
				end
			unitThreat = GetThreat("raidpet"..i, "target")	
				if unitThreat > highThreat then 
					highThreat = unitThreat	
					highUnit = UnitName("raidpet"..i)
					highUnitColorR, highUnitColorG, highUnitColorB = GetClassColor("raidpet"..i)
					unitThreatValue = GetThreatValue("raidpet"..i, "target")
				end
			unitThreat = GetThreat("pet", "target")
				if unitThreat > highThreat then
					highThreat = unitThreat
					highUnit = UnitName("pet")
					highUnitColorR, highUnitColorG, highUnitColorB = GetClassColor("pet")
					unitThreatValue = GetThreatValue("pet", "target")
				end
			unitTanking = GetTank("raid"..i, "target")
			if unitTanking == true then
				unitTankingColorR, unitTankingColorG, unitTankingColorB = GetClassColor("raid"..i)
				tankName = UnitName("raid"..i)
			end
			unitTanking = GetTank("raidpet"..i, "target")
			if unitTanking == true then
				unitTankingColorR, unitTankingColorG, unitTankingColorB = GetClassColor("raidpet"..i)
				tankName = UnitName("raidpet"..i)
			end
			unitTanking = GetTank("pet", "target")
			if unitTanking == true then
				unitTankingColorR, unitTankingColorG, unitTankingColorB = GetClassColor("pet")
				tankName = UnitName("pet")
			end
		end
		end
	elseif IsInRaid() and UnitCanAttack("player", "targettarget") and not (UnitCanAttack("player", "target") or UnitIsDead("targettarget") or UnitIsFriend("player", "targettarget") or UnitPlayerControlled("targettarget")) then --Raid Target of Target
		status = GetThreatStatus("player", "targettarget")
		threatpct = GetThreat("player", "targettarget")	
		playerThreatValue = GetThreatValue("player", "targettarget")
		for i = 1, GetNumGroupMembers() do
		if not UnitIsUnit("player", "raid"..i) then
			unitThreat = GetThreat("raid"..i, "targettarget") 	
				if unitThreat > highThreat then 
					highThreat = unitThreat	
					highUnit = UnitName("raid"..i)
					highUnitColorR, highUnitColorG, highUnitColorB = GetClassColor("raid"..i)
					unitThreatValue = GetThreatValue("raid"..i, "targettarget")
				end
			unitThreat = GetThreat("raidpet"..i, "targettarget")	
				if unitThreat > highThreat then 
					highThreat = unitThreat	
					highUnit = UnitName("raidpet"..i)
					highUnitColorR, highUnitColorG, highUnitColorB = GetClassColor("raidpet"..i)
					unitThreatValue = GetThreatValue("raidpet"..i, "targettarget")
				end
			unitThreat = GetThreat("pet", "targettarget")
				if unitThreat > highThreat then
					highThreat = unitThreat
					highUnit = UnitName("pet")
					highUnitColorR, highUnitColorG, highUnitColorB = GetClassColor("pet")
					unitThreatValue = GetThreatValue("pet", "targettarget")
				end
			unitTanking = GetTank("raid"..i, "targettarget")
			if unitTanking == true then
				unitTankingColorR, unitTankingColorG, unitTankingColorB = GetClassColor("raid"..i)
				tankName = UnitName("raid"..i)
			end
			unitTanking = GetTank("raidpet"..i, "targettarget")
			if unitTanking == true then
				unitTankingColorR, unitTankingColorG, unitTankingColorB = GetClassColor("raidpet"..i)
				tankName = UnitName("raidpet"..i)
			end
			unitTanking = GetTank("pet", "targettarget")
			if unitTanking == true then
				unitTankingColorR, unitTankingColorG, unitTankingColorB = GetClassColor("pet")
				tankName = UnitName("pet")
			end
		end
		end
	elseif IsInGroup() and UnitCanAttack("player", "target") and not (UnitIsDead("target") or UnitIsFriend("player", "target") or UnitPlayerControlled("target")) then -- Party Target 
		status = GetThreatStatus("player", "target")
		threatpct = GetThreat("player", "target")
		playerThreatValue = GetThreatValue("player", "target")
		for i = 1, GetNumSubgroupMembers() do
			unitThreat = GetThreat("party"..i, "target") 	
				if unitThreat > highThreat then 
					highThreat = unitThreat	
					highUnit = UnitName("party"..i)
					highUnitColorR, highUnitColorG, highUnitColorB = GetClassColor("party"..i)
					unitThreatValue = GetThreatValue("party"..i, "target")
				end
			unitThreat = GetThreat("partypet"..i, "target")	
				if unitThreat > highThreat then 
					highThreat = unitThreat	
					highUnit = UnitName("partypet"..i)
					highUnitColorR, highUnitColorG, highUnitColorB = GetClassColor("partypet"..i)
					unitThreatValue = GetThreatValue("partypet"..i, "target")
				end
			unitThreat = GetThreat("pet", "target")
				if unitThreat > highThreat then
					highThreat = unitThreat
					highUnit = UnitName("pet")
					highUnitColorR, highUnitColorG, highUnitColorB = GetClassColor("pet")
					unitThreatValue = GetThreatValue("pet", "target")
				end
			unitTanking = GetTank("party"..i, "target")
			if unitTanking == true then
				unitTankingColorR, unitTankingColorG, unitTankingColorB = GetClassColor("party"..i)
				tankName = UnitName("party"..i)
			end
			unitTanking = GetTank("partypet"..i, "target")
			if unitTanking == true then
				unitTankingColorR, unitTankingColorG, unitTankingColorB = GetClassColor("partypet"..i)
				tankName = UnitName("partypet"..i)
			end
			unitTanking = GetTank("pet", "target")
			if unitTanking == true then
				unitTankingColorR, unitTankingColorG, unitTankingColorB = GetClassColor("pet")
				tankName = UnitName("pet")
			end
		end
	elseif IsInGroup() and UnitCanAttack("player", "targettarget") and not (UnitCanAttack("player", "target") or UnitIsDead("targettarget") or UnitIsFriend("player", "targettarget") or UnitPlayerControlled("targettarget")) then --Party Target of Target
		status = GetThreatStatus("player", "targettarget")
		threatpct = GetThreat("player", "targettarget")
		playerThreatValue = GetThreatValue("player", "targettarget")
		for i = 1, GetNumSubgroupMembers() do
			unitThreat = GetThreat("party"..i, "targettarget") 	
				if unitThreat > highThreat then 
					highThreat = unitThreat	
					highUnit = UnitName("party"..i)
					highUnitColorR, highUnitColorG, highUnitColorB = GetClassColor("party"..i)
					unitThreatValue = GetThreatValue("party"..i, "targettarget")
				end
			unitThreat = GetThreat("partypet"..i, "targettarget")	
				if unitThreat > highThreat then 
					highThreat = unitThreat	
					highUnit = UnitName("partypet"..i)
					highUnitColorR, highUnitColorG, highUnitColorB = GetClassColor("partypet"..i)
					unitThreatValue = GetThreatValue("partypet"..i, "targettarget")
				end
			unitThreat = GetThreat("pet", "targettarget")
				if unitThreat > highThreat then
					highThreat = unitThreat
					highUnit = UnitName("pet")
					highUnitColorR, highUnitColorG, highUnitColorB = GetClassColor("pet")
					unitThreatValue = GetThreatValue("pet", "targettarget")
				end
			unitTanking = GetTank("party"..i, "targettarget")
			if unitTanking == true then
				unitTankingColorR, unitTankingColorG, unitTankingColorB = GetClassColor("party"..i)
				tankName = UnitName("party"..i)
			end
			unitTanking = GetTank("partypet"..i, "targettarget")
			if unitTanking == true then
				unitTankingColorR, unitTankingColorG, unitTankingColorB = GetClassColor("partypet"..i)
				tankName = UnitName("partypet"..i)
			end
			unitTanking = GetTank("pet", "target")
			if unitTanking == true then
				unitTankingColorR, unitTankingColorG, unitTankingColorB = GetClassColor("pet")
				tankName = UnitName("pet")
			end
		end
	end
	--[[if UnitExists("targettarget") and not UnitIsUnit("targettarget", "player") and not tankName then -- check for NPC and others not in group
		if not (UnitCanAttack("player", "targettarget") or UnitIsDead("targettarget") or UnitIsFriend("player", "target")) then -- targettarget tank
			tankName = UnitName("targettarget")
			unitThreatValue = GetThreatValue("targettarget", "target")
			unitTankingColorR, unitTankingColorG, unitTankingColorB = GetClassColor("targettarget")
		elseif UnitCanAttack("player", "targettarget") and not (UnitCanAttack("player", "target") or UnitIsDead("targettarget") or UnitIsFriend("player", "targettarget")) then -- target tank
			tankName = UnitName("target")
			unitThreatValue = GetThreatValue("target", "targettarget")
			unitTankingColorR, unitTankingColorG, unitTankingColorB = GetClassColor("target")
		end
	end]]
	if status then -- show frame	
		if self.db.profile.hidden == true and not threatbar:IsShown() then
			threatbar:Show()
		end
	end
	if status == 0 then
		--icon:SetTexCoord(GetTexCoordsForRoleSmallCircle("DAMAGER"))
		font2:SetText(string.format("%d %%", threatpct ))
		threatbar:SetValue(threatpct)
		threatbar:SetStatusBarColor(self.db.profile.status0Red, self.db.profile.status0Green, self.db.profile.status0Blue, self.db.profile.status0Alpha)

		if tankName then
			--icon:SetTexCoord(GetTexCoordsForRoleSmallCircle("TANK"))
			--icon:Show() 
			font1:SetText(tankName)
			font1:SetTextColor(unitTankingColorR, unitTankingColorG, unitTankingColorB, 1)
			--BasicThreatBar:Print(unitTankingColorR, unitTankingColorG, unitTankingColorB) --debug message
			if not self.db.profile.percent then
				font2:SetText(string.format("%s | %d %%", GetShortTV((unitThreatValue - playerThreatValue)), threatpct ))
			end
			threatbar:SetValue(threatpct)
			if currenttarget then -- display temporary threat bar
				if unitThreatValue == 0 then
					tempthreatpct = 100
				else
					tempthreatpct = floor((currenttarget / unitThreatValue) * 100)
				end
				font1:SetText(tankName)
				font1:SetTextColor(unitTankingColorR, unitTankingColorG, unitTankingColorB, 1)
				if not self.db.profile.percent then
					font2:SetText(string.format("%s | %d %%", GetShortTV((unitThreatValue - currenttarget)), tempthreatpct ))
				end
				threatbar:SetValue(tempthreatpct)
				threatbar:SetStatusBarColor(self.db.profile.tempthreatRed, self.db.profile.tempthreatGreen, self.db.profile.tempthreatBlue, self.db.profile.tempthreatAlpha)
			end
		end
	elseif status == 1 then
		--icon:SetTexCoord(GetTexCoordsForRoleSmallCircle("DAMAGER"))
		font2:SetText(string.format("%d %%", threatpct ))
		threatbar:SetValue(threatpct)
		threatbar:SetStatusBarColor(self.db.profile.status1Red, self.db.profile.status1Green, self.db.profile.status1Blue, self.db.profile.status1Alpha)
		
		if tankName then
			--icon:SetTexCoord(GetTexCoordsForRoleSmallCircle("TANK"))
			--icon:Show()  
			font1:SetText(tankName)
			font1:SetTextColor(unitTankingColorR, unitTankingColorG, unitTankingColorB, 1)
			--BasicThreatBar:Print(unitTankingColorR, unitTankingColorG, unitTankingColorB) --debug message
			if not self.db.profile.percent then
				font2:SetText(string.format("%s | %d %%", GetShortTV((unitThreatValue - playerThreatValue)), threatpct ))
			end
			threatbar:SetValue(threatpct)
			if currenttarget then -- display temporary threat bar
				if unitThreatValue == 0 then
					tempthreatpct = 100
				else
					tempthreatpct = floor((currenttarget / unitThreatValue) * 100)
				end
				font1:SetText(tankName)
				font1:SetTextColor(unitTankingColorR, unitTankingColorG, unitTankingColorB, 1)
				if not self.db.profile.percent then
					font2:SetText(string.format("%s | %d %%", GetShortTV((unitThreatValue - currenttarget)), tempthreatpct ))
				end
				threatbar:SetValue(tempthreatpct)
				threatbar:SetStatusBarColor(self.db.profile.tempthreatRed, self.db.profile.tempthreatGreen, self.db.profile.tempthreatBlue, self.db.profile.tempthreatAlpha)
			end
		end
	elseif status == 2 then
		--icon:SetTexCoord(GetTexCoordsForRoleSmallCircle("DAMAGER"))
		font2:SetText("WEAK AGGRO!")
		threatbar:SetValue(threatpct)
		threatbar:SetStatusBarColor(self.db.profile.status2Red, self.db.profile.status2Green, self.db.profile.status2Blue, self.db.profile.status2Alpha)
		
		if highUnit then
			--icon:SetTexCoord(GetTexCoordsForRoleSmallCircle("DAMAGER"))
			--icon:Show()
			threatdiff = (threatpct - highThreat)
			font1:SetText(highUnit)
			font1:SetTextColor(highUnitColorR, highUnitColorG, highUnitColorB, 1)
			if not self.db.profile.percent then
				font2:SetText(string.format("%s | %s %%", GetShortTV((playerThreatValue - unitThreatValue)), threatdiff ))
			else
				font2:SetText(string.format("%d %%", threatdiff ))
			end
			threatbar:SetValue(threatdiff)
			threatbar:SetBackdropColor(self.db.profile.status2depletedRed, self.db.profile.status2depletedGreen, self.db.profile.status2depletedBlue, self.db.profile.status2depletedAlpha)
			if currenttarget then -- display temporary threat bar
				if unitThreatValue == 0 then
					threatdiff = 100
				else
					threatdiff = floor((currenttarget / unitThreatValue) * 100) - highThreat
				end
				font1:SetText(highUnit)
				font1:SetTextColor(highUnitColorR, highUnitColorG, highUnitColorB, 1)
				if not self.db.profile.percent then
					font2:SetText(string.format("%s | %s %%", GetShortTV((currenttarget - unitThreatValue)), threatdiff ))
				else
					font2:SetText(string.format("%d %%", threatdiff ))
				end
				threatbar:SetValue(threatdiff)
				threatbar:SetStatusBarColor(self.db.profile.tempthreatRed, self.db.profile.tempthreatGreen, self.db.profile.tempthreatBlue, self.db.profile.tempthreatAlpha)
			end
		end	
	elseif status == 3 then
		--icon:SetTexCoord(GetTexCoordsForRoleSmallCircle("DAMAGER"))
		font2:SetText("AGGRO!")
		threatbar:SetValue(threatpct)
		threatbar:SetStatusBarColor(self.db.profile.status3Red, self.db.profile.status3Green, self.db.profile.status3Blue, self.db.profile.status3Alpha)
		
		if highUnit then
			--icon:SetTexCoord(GetTexCoordsForRoleSmallCircle("DAMAGER"))
			--icon:Show()  
			threatdiff = (threatpct - highThreat)
			font1:SetText(highUnit)
			font1:SetTextColor(highUnitColorR, highUnitColorG, highUnitColorB, 1)
			if not self.db.profile.percent then
				font2:SetText(string.format("%s | %s %%", GetShortTV((playerThreatValue - unitThreatValue)), threatdiff ))
			else
				font2:SetText(string.format("%d %%", threatdiff ))
			end
			threatbar:SetValue(threatdiff)
			threatbar:SetBackdropColor(self.db.profile.status3depletedRed, self.db.profile.status3depletedGreen, self.db.profile.status3depletedBlue, self.db.profile.status3depletedAlpha)
			if currenttarget then -- display temporary threat bar 
				if unitThreatValue == 0 then
					threatdiff = 100
				else
					threatdiff = floor((currenttarget / unitThreatValue) * 100) - highThreat
				end
				font1:SetText(highUnit)
				font1:SetTextColor(highUnitColorR, highUnitColorG, highUnitColorB, 1)
				if not self.db.profile.percent then
					font2:SetText(string.format("%s | %s %%", GetShortTV((currenttarget - unitThreatValue)), threatdiff ))
				else
					font2:SetText(string.format("%d %%", threatdiff ))
				end
				threatbar:SetValue(threatdiff)
				threatbar:SetStatusBarColor(self.db.profile.tempthreatRed, self.db.profile.tempthreatGreen, self.db.profile.tempthreatBlue, self.db.profile.tempthreatAlpha)
			end
		end
	end
end
		
function BasicThreatBar:COMBAT_LOG_EVENT_UNFILTERED(event, ...)
		local timestamp, eventtype, hideCaster, srcGUID, srcName, srcFlags, srcFlags2, dstGUID, dstName, dstFlags, dstFlags2 = ...
		local targetGUID = UnitGUID("target")
		local damage
		local playerGUID = UnitGUID("player")
		if srcGUID == playerGUID then
		if eventtype == "SPELL_AURA_APPLIED" then
			local spellID = select(12, ...)
			if spellID == 55342 or spellID == 586 then
				--DEFAULT_CHAT_FRAME:AddMessage("Temp spell casted") --debug message
				fademiActive = true
				StoreThreat()		-- set temp threat to last known threat value
			elseif spellID == 32612 and fademiActive == true then -- Invisibility buff while Mirror Image is active
				wipe(tempthreat)
			end
		elseif eventtype == "SPELL_DAMAGE" or eventtype == "RANGE_DAMAGE" or eventtype == "SPELL_PERIODIC_DAMAGE" then
			if fademiActive == true then
			--DEFAULT_CHAT_FRAME:AddMessage("Detecting damage") --debug message
			damage = select(15, ...)
			
			end
		elseif eventtype == "SWING_DAMAGE" then
			if fademiActive == true then
			damage = select(12, ...)
			
			end
		elseif eventtype == "SPELL_AURA_REMOVED" then
			local spellID = select(12, ...)
			if spellID == 55342 or spellID == 586 then
				--DEFAULT_CHAT_FRAME:AddMessage("Temp spell expired") --debug message
				wipe(tempthreat) -- clear table
				damage = nil
				fademiActive = nil
				currenttarget = nil
			end	
		end
		if damage then
			tempthreat[dstGUID] = (tempthreat[dstGUID] or 0) + damage
			if targetGUID == dstGUID then
				currenttarget = tempthreat[dstGUID]
			end
		end
		end
		
end
	
function BasicThreatBar:PLAYER_TARGET_CHANGED(event)
		local targetGUID = UnitGUID("target")
		if fademiActive == true then
			local intable = tContains(tempthreat, targetGUID)
			if not intable then
				currenttarget = nil
				--DEFAULT_CHAT_FRAME:AddMessage("currentarget set to nil") -- debug message
			end
			for index,value in pairs(tempthreat) do 
				if targetGUID == index then
					currenttarget = value
					--DEFAULT_CHAT_FRAME:AddMessage(tostring(index).." : "..tostring(value)) -- debug message
				
				end
			
			end

		UpdateDisplay()
	else
		UpdateDisplay()
	end
	
end

function BasicThreatBar:UNIT_THREAT_SITUATION_UPDATE(event, unitId)
	UpdateDisplay()
end

function BasicThreatBar:UNIT_THREAT_LIST_UPDATE(event, mobId)
	UpdateDisplay()
end

function BasicThreatBar:GROUP_ROSTER_UPDATE(event)
	UpdateDisplay()
end

function BasicThreatBar:UNIT_TARGET(event, unitId)
	if UnitCanAttack("player", "targettarget") and not (UnitCanAttack("player", "target") or UnitIsDead("targettarget") or UnitIsFriend("player", "targettarget") or UnitPlayerControlled("targettarget")) then
		threatbar:SetScript("OnUpdate", function(self, elap)
		elapsed = elapsed + elap
		if elapsed < UPDATEPERIOD then return end

		elapsed = 0
		UpdateDisplay()
		end)
	else
		threatbar:SetScript("OnUpdate", nil)
	end
end
