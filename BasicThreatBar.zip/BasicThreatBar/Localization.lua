local AL3 = LibStub("AceLocale-3.0")
local debug = false
--[===[@debug@
debug = true
--@end-debug@]===]

local L = AL3:NewLocale("BasicThreatBar", "enUS", true, debug)
if L then
L["% only"] = true
L["Adds a thick black outline to the font"] = true
L["Adds outline to the font"] = true
L["Background"] = true
L["Bar"] = true
L["Bar Height"] = true
L["Bar Width"] = true
L["Border"] = true
L["Border Color"] = true
L["Borders"] = true
L["Bottom"] = true
L["Bottom Left"] = true
L["Bottom Right"] = true
L["Center"] = true
L["Change the alignment of the name text"] = true
L["Change the alignment of the threat text"] = true
L["Change the bar texture"] = true
L["Change the bar's border"] = true
L["Change the font"] = true
L["Change the strata of the bar"] = true
L["Changes the bar to fill vertically"] = true
L["Changes the color of pet names"] = true
L["Changes the color of the bar for high tanking threat"] = true
L["Changes the color of the bar for high threat"] = true
L["Changes the color of the bar for low tanking threat"] = true
L["Changes the color of the bar for low threat"] = true
L["Changes the color of the bar for temporary threat while under fade or mirror image"] = true
L["Changes the color of the border"] = true
L["Changes the color of the empty portion of the bar for high aggro"] = true
L["Changes the color of the empty portion of the bar for low aggro"] = true
L["Changes the color of the empty portion of the bar for low and high threat"] = true
L["Changes the color of the threat text"] = true
L["Class color pets"] = true
L["Color pets by class"] = true
L["Depleted color"] = true
L["Disable the bar when not in a group and no pet is active"] = true
L["Disable when solo"] = true
L["Display only threat % without value"] = true
L["Display sample text and value on the threat bar."] = true
L["Font size"] = true
L["Fonts"] = true
L["Hide the bar when not in combat and lock it in place"] = true
L["Hide/Lock bar"] = true
L["High"] = true
L["High aggro color"] = true
L["High aggro depleted color"] = true
L["High threat color"] = true
L["Left Inside"] = true
L["Left Outside"] = true
L["Low"] = true
L["Low aggro color"] = true
L["Low aggro depleted color"] = true
L["Low threat color"] = true
L["Medium"] = true
L["Monochrome"] = true
L["Name position"] = true
L["None"] = true
L["Outline"] = true
L["Pet color"] = true
L["Right Inside"] = true
L["Right Outside"] = true
L["Sample"] = true
L["Sets the font to monochrome"] = true
L["Strata"] = true
L["Temp threat color"] = true
L["Test"] = true
L["Text"] = true
L["Textures"] = true
L["Thick Outline"] = true
L["Threat position"] = true
L["Threat text color"] = true
L["Top"] = true
L["Top Left"] = true
L["Top Right"] = true
L["Vertical bar"] = true
if GetLocale() == "enUS" or GetLocale() == "enGB" then return end
end

local L = AL3:NewLocale("BasicThreatBar", "deDE")
if L then
L["% only"] = "nur %"
L["Adds a thick black outline to the font"] = "Fügt der Schrift eine dicke schwarze Kontur hinzu."
L["Adds outline to the font"] = "Fügt der Schrift eine Kontur hinzu"
L["Background"] = "Hintergrund"
L["Bar"] = "Leiste"
L["Bar Height"] = "Leistenhöhe"
L["Bar Width"] = "Leistenbreite"
L["Border"] = "Rand"
L["Border Color"] = "Randfarbe"
L["Borders"] = "Ränder"
L["Bottom"] = "Unten "
L["Bottom Left"] = "Unten links"
L["Bottom Right"] = "Unten rechts"
L["Center"] = "Mittig"
L["Change the alignment of the name text"] = "Ändert die Ausrichtung der Bezeichnung"
L["Change the alignment of the threat text"] = "Ändert die Ausrichtung des Bedrohungstexts"
L["Change the bar texture"] = "Ändert die Leistentextur"
L["Change the bar's border"] = "Ändert den Rand der Leiste"
L["Change the font"] = "Ändert die Schriftart"
L["Change the strata of the bar"] = "Ändert die Ebene der Leiste"
L["Changes the color of pet names"] = "Ändert die Farbe des Begleiternamens"
L["Changes the color of the bar for high tanking threat"] = "Ändert die Farbe des Balkens bei hoher Tank- Bedrohung"
L["Changes the color of the bar for high threat"] = "Ändert die Farbe des Balkens bei hoher Bedrohung"
L["Changes the color of the bar for low tanking threat"] = "Ändert die Farbe des Balkens bei niedriger Tank- Bedrohung"
L["Changes the color of the bar for low threat"] = "Ändert die Farbe des Balkens bei niedriger Bedrohung"
L["Changes the color of the bar for temporary threat while under fade or mirror image"] = "Ändert die Farbe des Balkens bei zeitweiser Bedrohung unter dem Einfluss von \"Verblassen\" oder \"Spiegelbild\""
L["Changes the color of the border"] = "Ändert die Farbe des Randes"
L["Disable when solo"] = "Deaktivieren, wenn solo"
L["Font size"] = "Schriftgröße"
L["Fonts"] = "Schriftarten"
L["Hide the bar when not in combat and lock it in place"] = "Verstecke den Balken außerhalb des Kampfes und fixiere die Position"
L["Hide/Lock bar"] = "Leiste fixieren/entsperren"
L["High"] = "Hoch"
L["High aggro color"] = "Farbe bei hoher Bedrohung"
L["High threat color"] = "Farbe für hohe Bedrohung"
L["Left Inside"] = "Links"
L["Left Outside"] = "Links außen"
L["Low"] = "Niedrig"
L["Low aggro color"] = "Farbe bei niedriger Bedrohung"
L["Low threat color"] = "Farbe bei niedriger Bedrohung"
L["Medium"] = "Mittel"
L["Monochrome"] = "Einfarbig"
L["Name position"] = "Namensposition"
L["None"] = "Nichts"
L["Outline"] = "Kontur"
L["Pet color"] = "Begleiterfarbe"
L["Right Inside"] = "Rechts"
L["Right Outside"] = "Rechts außen"
L["Sample"] = "Beispiel"
L["Strata"] = "Ebene"
L["Temp threat color"] = "Farbei bei zeitweiser Bedrohung"
L["Test"] = "Test"
L["Text"] = "Text"
L["Textures"] = "Texturen"
L["Thick Outline"] = "Dicke Kontur"
L["Threat position"] = "Bedrohungsposition"
L["Threat text color"] = "Farbe des Bedrohungstexts"
L["Top"] = "Oben"
L["Top Left"] = "Oben links"
L["Top Right"] = "Oben rechts"
L["Vertical bar"] = "Vertikale Leiste"
return
end

local L = AL3:NewLocale("BasicThreatBar", "esES") or AL3:NewLocale("BasicThreatBar", "esMX")
if L then
return
end

local L = AL3:NewLocale("BasicThreatBar", "frFR")
if L then
L["Bar"] = "Bar"
L["Border"] = "Frontière"
L["Border Color"] = "Couleur de la bordure"
L["Bottom"] = "Bas"
L["Center"] = "Centre"
L["Font size"] = "Taille de la police"
L["Fonts"] = "Polices"
L["Monochrome"] = "Monochrome"
L["Outline"] = "Contour"
L["Sample"] = "échantillon"
L["Test"] = "Test"
L["Text"] = "Texte"
L["Textures"] = "Textures"
L["Thick Outline"] = "Contour épais"
L["Threat text color"] = "Couleur du texte des menaces"
L["Top"] = "Haut"
return
end

local L = AL3:NewLocale("BasicThreatBar", "koKR")
if L then
return
end

local L = AL3:NewLocale("BasicThreatBar", "ruRU")
if L then
L["Adds a thick black outline to the font"] = "Добавить толстую обводку к шрифту"
L["Adds outline to the font"] = "Добавить обводку к шрифту"
L["Bar"] = "Панель"
L["Bar Height"] = "Высота панели"
L["Bar Width"] = "Ширина панели"
L["Border"] = "Граница"
L["Border Color"] = "Цвет границы"
L["Borders"] = "Границы"
L["Bottom"] = "Снизу"
L["Bottom Left"] = "Снизу слева"
L["Bottom Right"] = "Снизу справа"
L["Center"] = "По центру"
L["Change the alignment of the name text"] = "Изменить привязку текста имени"
L["Change the alignment of the threat text"] = "Изменить привязку текста угрозы"
L["Change the bar texture"] = "Изменить текстуру панели"
L["Change the bar's border"] = "Изменить границу панели"
L["Change the font"] = "Изменить шрифт"
L["Changes the color of the border"] = "Изменение границы панели"
L["Display sample text and value on the threat bar."] = "Показать пример текста и значения панели угрозы"
L["Font size"] = "Размер шрифта"
L["Fonts"] = "Шрифты"
L["Hide the bar when not in combat and lock it in place"] = "Скрыть панель вне боя и зафиксировать её место"
L["Hide/Lock bar"] = "Скрыть/заблокировать панель"
L["Left Inside"] = "Слева внутри"
L["Monochrome"] = "Монохромный"
L["Name position"] = "Позиция имени"
L["Outline"] = "Обводка"
L["Right Inside"] = "Справа внутри"
L["Sample"] = "Пример"
L["Sets the font to monochrome"] = "Установить монохромный шрифт"
L["Test"] = "Тест"
L["Text"] = "Текст"
L["Textures"] = "Текстуры"
L["Thick Outline"] = "Толстая обводка"
L["Threat position"] = "Позиция угрозы"
L["Threat text color"] = "Цвет текста угрозы"
L["Top"] = "Сверху"
L["Top Left"] = "Сверху слева"
L["Top Right"] = "Сверху справа"
return
end

local L = AL3:NewLocale("BasicThreatBar", "zhCN")
if L then
return
end

local L = AL3:NewLocale("BasicThreatBar", "zhTW")
if L then
L["% only"] = "只有%"
L["Adds a thick black outline to the font"] = "文字添加粗描邊"
L["Adds outline to the font"] = "文字添加描邊"
L["Background"] = "背景"
L["Bar"] = "威脅條"
L["Bar Height"] = "威脅條高度"
L["Bar Width"] = "威脅條寬度"
L["Border"] = "外框"
L["Border Color"] = "外框顏色"
L["Borders"] = "外框"
L["Bottom"] = "下"
L["Bottom Left"] = "左下"
L["Bottom Right"] = "右下"
L["Center"] = "中間"
L["Change the alignment of the name text"] = "改變名稱文字的對齊方式"
L["Change the alignment of the threat text"] = "改變威脅文字的對齊方式"
L["Change the bar texture"] = "改變威脅條材質"
L["Change the bar's border"] = "改變威脅條的外框"
L["Change the font"] = "改變字型"
L["Change the strata of the bar"] = "改變威脅條層級"
L["Changes the bar to fill vertically"] = "將威脅條垂直擺放"
L["Changes the color of pet names"] = "改變寵物名稱的顏色"
L["Changes the color of the bar for high tanking threat"] = "改變當坦克仇恨高時的顏色"
L["Changes the color of the bar for high threat"] = "改變高威脅時的顏色"
L["Changes the color of the bar for low tanking threat"] = "改變當坦克仇恨低時的顏色"
L["Changes the color of the bar for low threat"] = "改變低威脅時的顏色"
L["Changes the color of the bar for temporary threat while under fade or mirror image"] = "改變當消失或鏡像體時暫時威脅的顏色"
L["Changes the color of the border"] = "改變外框的顏色"
L["Changes the color of the empty portion of the bar for high aggro"] = "改變當高仇恨時空白區域的顏色"
L["Changes the color of the empty portion of the bar for low aggro"] = "改變當低仇恨時空白區域的顏色"
L["Changes the color of the empty portion of the bar for low and high threat"] = "改變當低或高威脅時空白區域的顏色"
L["Changes the color of the threat text"] = "改變威脅文字的顏色"
L["Class color pets"] = "職業著色寵物"
L["Color pets by class"] = "依據職業著色寵物"
L["Depleted color"] = "空白區域顏色"
L["Disable the bar when not in a group and no pet is active"] = "當不在隊伍並且沒有寵物活動時停用威脅條"
L["Disable when solo"] = "單獨時停用"
L["Display only threat % without value"] = "只顯示威脅%不包含數值"
L["Display sample text and value on the threat bar."] = "顯示範例文字與數字在威脅條上。"
L["Font size"] = "字型尺寸"
L["Fonts"] = "字型"
L["Hide the bar when not in combat and lock it in place"] = "當非戰鬥中隱藏此條並鎖定位置"
L["Hide/Lock bar"] = "隱藏/鎖定 威脅條"
L["High"] = "高"
L["High aggro color"] = "高仇恨顏色"
L["High aggro depleted color"] = "高仇恨空白顏色"
L["High threat color"] = "高威脅顏色"
L["Left Inside"] = "左內側"
L["Left Outside"] = "左外側"
L["Low"] = "低"
L["Low aggro color"] = "低仇恨顏色"
L["Low aggro depleted color"] = "低仇恨空白顏色"
L["Low threat color"] = "低威脅顏色"
L["Medium"] = "中"
L["Monochrome"] = "單色"
L["Name position"] = "名稱位置"
L["None"] = "無"
L["Outline"] = "描邊"
L["Pet color"] = "寵物顏色"
L["Right Inside"] = "右內側"
L["Right Outside"] = "右外側"
L["Sample"] = "範例"
L["Sets the font to monochrome"] = "設定文字為單色調"
L["Strata"] = "層級"
L["Temp threat color"] = "暫時威脅顏色"
L["Test"] = "測試"
L["Text"] = "文字"
L["Textures"] = "材質"
L["Thick Outline"] = "粗描邊"
L["Threat position"] = "威脅位置"
L["Threat text color"] = "威脅文字顏色"
L["Top"] = "上"
L["Top Left"] = "左上"
L["Top Right"] = "右上"
L["Vertical bar"] = "將條垂直"
return
end

local L = AL3:NewLocale("BasicThreatBar", "ptBR")
if L then
return
end
