V7.2
- Updated to reflect wow 7.2 map code changes