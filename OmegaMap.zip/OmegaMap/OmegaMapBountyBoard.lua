OmegaMapBountyBoardMixin = {};

function OmegaMapBountyBoardMixin:OnLoad()
	self:RegisterEvent("QUEST_LOG_UPDATE");
	self.bountyObjectivePool = CreateFramePool("FRAME", self, "OmegaMapBountyBoardObjectiveTemplate");
	self.bountyTabPool = CreateFramePool("BUTTON", self, "OmegaMapBountyBoardTabTemplate");

	self.BountyName:SetFontObjectsToTry(Game13Font_o1, Game12Font_o1, Game11Font_o1);

	self.minimumTabsToDisplay = 3;
	self.maps = {};
	self.highestMapInfo = {};
end

function OmegaMapBountyBoardMixin:OnEvent(event, ...)
	if event == "QUEST_LOG_UPDATE" then
		if not self:GetParent() or self:GetParent():IsVisible() then
			self:Refresh();
		end
	end
end

function OmegaMapBountyBoardMixin:OnShow()
	if not self.isRefreshing then
		self:Refresh();
	end
end

function OmegaMapBountyBoardMixin:SetMapAreaID(mapAreaID)
	if self.mapAreaID ~= mapAreaID then
		self.mapAreaID = mapAreaID;
		self:Refresh();
	end
end

function OmegaMapBountyBoardMixin:GetDisplayLocation()
	return self.displayLocation;
end

function OmegaMapBountyBoardMixin:SetSelectedBountyChangedCallback(selectedBountyChangedCallback)
	self.selectedBountyChangedCallback = selectedBountyChangedCallback;
end

function OmegaMapBountyBoardMixin:IsWorldQuestCriteriaForSelectedBounty(questID)
	if self.bounties and self.selectedBountyIndex then
		local bounty = self.bounties[self.selectedBountyIndex];
		if bounty and IsQuestCriteriaForBounty(questID, bounty.questID) then
			return true;
		end
	end
	return false;
end

function OmegaMapBountyBoardMixin:Clear()
	self.selectedBountyIndex = nil;
	self:Hide();
end

OMEGA_MAP_BOUNTY_BOARD_LOCK_TYPE_NONE = 1;
OMEGA_MAP_BOUNTY_BOARD_LOCK_TYPE_BY_QUEST = 2;
OMEGA_MAP_BOUNTY_BOARD_LOCK_TYPE_NO_BOUNTIES = 3;

function OmegaMapBountyBoardMixin:Refresh()
	assert(not self.isRefreshing);
	self.isRefreshing = true;

	self.firstCompletedTab = nil;
	self.TutorialBox:Hide();

	self.bountyTabPool:ReleaseAll();
	self.bountyObjectivePool:ReleaseAll();

	if not self.mapAreaID then
		self:Clear();
		self.isRefreshing = false;
		return;
	end

	self.bounties, self.displayLocation, self.lockedQuestID = GetQuestBountyInfoForMapID(self.mapAreaID, self.bounties);

	if not self.displayLocation then
		self:Clear();
		self.isRefreshing = false;
		return;
	end

	if self.lockedQuestID then
		self:SetLockedType(OMEGA_MAP_BOUNTY_BOARD_LOCK_TYPE_BY_QUEST);
	elseif #self.bounties == 0 then
		self:SetLockedType(OMEGA_MAP_BOUNTY_BOARD_LOCK_TYPE_NO_BOUNTIES);

		self.selectedBountyIndex = nil;

		self:RefreshBountyTabs();
	else
		self:SetLockedType(OMEGA_MAP_BOUNTY_BOARD_LOCK_TYPE_NONE);
		self.selectedBountyIndex = self.bounties[self.selectedBountyIndex] and self.selectedBountyIndex or 1;

		self:RefreshBountyTabs();
		self:RefreshSelectedBounty();
	end

	self:Show();

	self:TryShowingIntroTutorial();
	self:TryShowingCompletionTutorial();

	self.isRefreshing = false;
end

function OmegaMapBountyBoardMixin:SetLockedType(lockedType)
	self.lockedType = lockedType;

	self.DesaturatedTrackerBackground:SetShown(self.lockedType ~= OMEGA_MAP_BOUNTY_BOARD_LOCK_TYPE_NONE);
	self.Locked:SetShown(self.lockedType == OMEGA_MAP_BOUNTY_BOARD_LOCK_TYPE_BY_QUEST);

	if self.lockedType ~= OMEGA_MAP_BOUNTY_BOARD_LOCK_TYPE_NONE then
		self.BountyName:SetText(BOUNTY_BOARD_LOCKED_TITLE);
		self.BountyName:SetVertexColor(.5, .5, .5);

		self:ShowQuestObjectiveMarkers(0, 5, .3);
	else
		self.BountyName:SetVertexColor(NORMAL_FONT_COLOR:GetRGB());
	end
end

function OmegaMapBountyBoardMixin:AnchorBountyTab(tab)
	local TAB_WIDTH = 44;
	local PADDING = -7;
	local startX = -((math.max(#self.bounties, self.minimumTabsToDisplay)  - 1) * (TAB_WIDTH + PADDING)) / 2;

	local offsetX = (PADDING + TAB_WIDTH) * (tab.bountyIndex - 1);
	tab:SetPoint("CENTER", self.TrackerBackground, "CENTER", startX + offsetX, 43);
end

function OmegaMapBountyBoardMixin:RefreshBountyTabs()
	self.bountyTabPool:ReleaseAll();

	if self.lockedType ~= OMEGA_MAP_BOUNTY_BOARD_LOCK_TYPE_NONE and self.lockedType ~= OMEGA_MAP_BOUNTY_BOARD_LOCK_TYPE_NO_BOUNTIES then
		return;
	end

	for bountyIndex, bounty in ipairs(self.bounties) do
		local tab = self.bountyTabPool:Acquire();
		local selected = self.selectedBountyIndex == bountyIndex;
		tab:SetNormalAtlas(selected and "worldquest-tracker-ring-selected" or "worldquest-tracker-ring");
		if selected then 
			tab:SetHighlightTexture(nil);
		else
			tab:SetHighlightAtlas("worldquest-tracker-ring");
			tab:GetHighlightTexture():SetAlpha(0.4);
		end		
		if IsQuestComplete(bounty.questID) then
			tab.CheckMark:Show();
			if not self.firstCompletedTab then
				self.firstCompletedTab = tab;
			end
		else
			tab.CheckMark:Hide();
		end
		
		tab.Icon:SetTexture(bounty.icon);
		tab.Icon:Show();
		tab.EmptyIcon:Hide();
		tab.bountyIndex = bountyIndex;
		tab.isEmpty = false;

		self:AnchorBountyTab(tab);
		tab:Show();
	end

	for bountyIndex = #self.bounties + 1, self.minimumTabsToDisplay do
		local tab = self.bountyTabPool:Acquire();

		tab:SetNormalAtlas("worldquest-tracker-ring");
		tab:SetHighlightTexture(nil);
		tab.CheckMark:Hide();
		tab.Icon:Hide();
		tab.EmptyIcon:Show();
		tab.bountyIndex = bountyIndex;
		tab.isEmpty = true;

		self:AnchorBountyTab(tab);
		tab:Show();
	end
end

function OmegaMapBountyBoardMixin:RefreshSelectedBounty()
	self.bountyObjectivePool:ReleaseAll();

	if self.lockedType ~= OMEGA_MAP_BOUNTY_BOARD_LOCK_TYPE_NONE then
		return;
	end

	if self.selectedBountyIndex then
		local bountyData = self.bounties[self.selectedBountyIndex];
		local questIndex = GetQuestLogIndexByID(bountyData.questID);
		if questIndex > 0 then
			local title, level, suggestedGroup, isHeader, isCollapsed, isComplete, frequency, questID, startEvent, displayQuestID, isOnMap, hasLocalPOI, isTask, isBounty, isStory = GetQuestLogTitle(questIndex);
			if title then
				self.BountyName:SetText(title);

				self:RefreshSelectedBountyObjectives(bountyData);
				return;
			end
		end
	end

	self.BountyName:SetText(RETRIEVING_DATA);
	self.BountyName:SetVertexColor(RED_FONT_COLOR:GetRGB());
end

local OMEGA_MAP_MAX_BOUNTY_OBJECTIVES = 7;
function OmegaMapBountyBoardMixin:RefreshSelectedBountyObjectives(bountyData)
	local numCompleted, numTotal = self:CalculateBountySubObjectives(bountyData);

	if numTotal == 0 then
		return;
	end

	self:ShowQuestObjectiveMarkers(numCompleted, numTotal);
end

function OmegaMapBountyBoardMixin:ShowQuestObjectiveMarkers(numCompleted, numTotal, alpha)
	local SUB_OBJECTIVE_FRAME_WIDTH = 35;

	local percentFull = (numTotal - 1) / (OMEGA_MAP_MAX_BOUNTY_OBJECTIVES - 1);
	local padding = Lerp(3, -9, percentFull);
	local startingOffsetX = -((SUB_OBJECTIVE_FRAME_WIDTH + padding) * (numTotal - 1)) / 2;

	self.bountyObjectivePool:ReleaseAll();
	for bountyObjectiveIndex = 1, numTotal do
		local bountyObjectiveFrame = self.bountyObjectivePool:Acquire();
		bountyObjectiveFrame:Show();

		local complete = bountyObjectiveIndex <= numCompleted;
		bountyObjectiveFrame.MarkerTexture:SetAtlas(complete and "worldquest-tracker-questmarker" or "worldquest-tracker-questmarker-gray", true);
		bountyObjectiveFrame.MarkerTexture:SetAlpha(alpha or 1.0);
		bountyObjectiveFrame.CheckMarkTexture:SetShown(complete);

		local offsetX = (padding + SUB_OBJECTIVE_FRAME_WIDTH) * (bountyObjectiveIndex - 1);
		bountyObjectiveFrame:SetPoint("CENTER", self.TrackerBackground, "CENTER", startingOffsetX + offsetX, -11);
	end
end

function OmegaMapBountyBoardMixin:CalculateBountySubObjectives(bountyData)
	local numCompleted = 0;
	local numTotal = 0;

	for objectiveIndex = 1, bountyData.numObjectives do
		local objectiveText, objectiveType, finished, numFulfilled, numRequired = GetQuestObjectiveInfo(bountyData.questID, objectiveIndex, false);
		if objectiveText and #objectiveText > 0 and numRequired > 0 then
			for objectiveSubIndex = 1, numRequired do
				if objectiveSubIndex <= numFulfilled then
					numCompleted = numCompleted + 1;
				end
				numTotal = numTotal + 1;

				if numTotal >= OMEGA_MAP_MAX_BOUNTY_OBJECTIVES then
					return numCompleted, numTotal;
				end
			end
		end
	end

	return numCompleted, numTotal;
end

function OmegaMapBountyBoardMixin:SetSelectedBountyIndex(selectedBountyIndex)
	if self.selectedBountyIndex ~= selectedBountyIndex then
		self.selectedBountyIndex = selectedBountyIndex;
		PlaySound("UI_WorldQuest_Map_Select");
		self:RefreshBountyTabs();
		self:RefreshSelectedBounty();
		if self.selectedBountyChangedCallback then
			self.selectedBountyChangedCallback(self);
		end
	end
end

function OmegaMapBountyBoardMixin:GetSelectedBountyIndex()
	return self.selectedBountyIndex;
end

local function AddObjectives(questID, numObjectives)
	for objectiveIndex = 1, numObjectives do
		local objectiveText, objectiveType, finished = GetQuestObjectiveInfo(questID, objectiveIndex, false);
		if objectiveText and #objectiveText > 0 then
			local color = finished and GRAY_FONT_COLOR or HIGHLIGHT_FONT_COLOR;
			OmegaMapTooltip:AddLine(QUEST_DASH .. objectiveText, color.r, color.g, color.b, true);
		end
	end
end

function OmegaMapBountyBoardMixin:ShowBountyTooltip(bountyIndex)
	local bountyData = self.bounties[bountyIndex];
	self:SetTooltipOwner();

	local questIndex = GetQuestLogIndexByID(bountyData.questID);
	local title, level, suggestedGroup, isHeader, isCollapsed, isComplete, frequency, questID, startEvent, displayQuestID, isOnMap, hasLocalPOI, isTask, isStory = GetQuestLogTitle(questIndex);
	
	if title then
		OmegaMapTooltip:SetText(title, HIGHLIGHT_FONT_COLOR:GetRGB());

		OmegaMap_AddQuestTimeToTooltip(bountyData.questID);

		local _, questDescription = GetQuestLogQuestText(questIndex);
		OmegaMapTooltip:AddLine(questDescription, NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b, true);

		AddObjectives(bountyData.questID, bountyData.numObjectives);

		GameTooltip_AddQuestRewardsToTooltip(OmegaMapTooltip, bountyData.questID);
		--OmegaMap_AddQuestRewardsToTooltip(bountyData.questID);
		OmegaMapTooltip:Show();
	else
		OmegaMapTooltip:SetText(RETRIEVING_DATA, RED_FONT_COLOR:GetRGB());
		OmegaMapTooltip:Show();
	end
end

function OmegaMapBountyBoardMixin:SetTooltipOwner()
	local x = self:GetRight();
	if x >= GetScreenWidth() / 2 then
		OmegaMapTooltip:SetOwner(self, "ANCHOR_LEFT", -100, -50);
	else
		OmegaMapTooltip:SetOwner(self, "ANCHOR_RIGHT", 0, -50);
	end	
end

function OmegaMapBountyBoardMixin:ShowLockedByQuestTooltip()
	local questIndex = GetQuestLogIndexByID(self.lockedQuestID);
	local title, level, suggestedGroup, isHeader, isCollapsed, isComplete, frequency, questID, startEvent, displayQuestID, isOnMap, hasLocalPOI, isTask, isStory = GetQuestLogTitle(questIndex);
	if title then
		self:SetTooltipOwner();

		OmegaMapTooltip:SetText(BOUNTY_BOARD_LOCKED_TITLE, HIGHLIGHT_FONT_COLOR:GetRGB());

		local _, questDescription = GetQuestLogQuestText(questIndex);
		OmegaMapTooltip:AddLine(questDescription, NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b, true);

		AddObjectives(self.lockedQuestID, GetNumQuestLeaderBoards(questIndex));

		OmegaMapTooltip:Show();
	end
end

function OmegaMapBountyBoardMixin:ShowLockedByNoBountiesTooltip(bountyIndex)
	self:SetTooltipOwner();

	local tooltipText;
	if bountyIndex then
		local daysUntilNext = bountyIndex - #self.bounties;
		tooltipText = _G["BOUNTY_BOARD_NO_BOUNTIES_DAYS_" .. daysUntilNext] or BOUNTY_BOARD_NO_BOUNTIES;
	else
		tooltipText = BOUNTY_BOARD_NO_BOUNTIES;
	end
	OmegaMapTooltip:SetText(tooltipText, NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b, true);

	OmegaMapTooltip:Show();
end

function OmegaMapBountyBoardMixin:OnEnter()
	if self.lockedType == OMEGA_MAP_BOUNTY_BOARD_LOCK_TYPE_NONE then
		if self.selectedBountyIndex then
			self:ShowBountyTooltip(self.selectedBountyIndex);
		end
	elseif self.lockedType == OMEGA_MAP_BOUNTY_BOARD_LOCK_TYPE_BY_QUEST then
		self:ShowLockedByQuestTooltip();
	elseif self.lockedType == OMEGA_MAP_BOUNTY_BOARD_LOCK_TYPE_NO_BOUNTIES then
		self:ShowLockedByNoBountiesTooltip(nil);
	end
end

function OmegaMapBountyBoardMixin:OnLeave()
	OmegaMapTooltip:Hide();
end

function OmegaMapBountyBoardMixin:OnTabEnter(tab)
	if tab.isEmpty then
		self:ShowLockedByNoBountiesTooltip(tab.bountyIndex);
	else
		self:ShowBountyTooltip(tab.bountyIndex);
	end
end

function OmegaMapBountyBoardMixin:OnTabLeave(tab)
	self:OnLeave();
end

function OmegaMapBountyBoardMixin:OnTabClick(tab)
	if not tab.isEmpty then
		if (self:GetSelectedBountyIndex() ~= tab.bountyIndex) then
			self.currentCandidateIndex = nil;
		end
		self:SetSelectedBountyIndex(tab.bountyIndex);
		self:FindBestMapForSelectedBounty();
	end
end

function OmegaMapBountyBoardMixin:CacheWorldQuestDataForSelectedBounty()
	local continentIndex, continentID = GetCurrentMapContinent();
	local continentMaps =  { GetMapZones(continentIndex) };

	local maxQuests = 0;
	for i = 1, #continentMaps, 2 do
		local numQuests = 0;
		local taskInfo = C_TaskQuest.GetQuestsForPlayerByMapID(continentMaps[i], continentID);
		for _, info  in ipairs(taskInfo) do
			if QuestUtils_IsQuestWorldQuest(info.questId) then
				if self:IsWorldQuestCriteriaForSelectedBounty(info.questId) then
					numQuests = numQuests + 1;
				end
			end
		end
		-- The maps don't have a defined order, so we keep some semblance of order by reusing indexes.
		local index = FindInTableIf(self.maps, function(v) return v.mapID == continentMaps[i] end);
		if index then
			self.maps[index].numQuests = numQuests;
		else
			tinsert(self.maps, { mapID = continentMaps[i], numQuests = numQuests });
		end
		if (numQuests > maxQuests) then
			self.highestMapInfo.mapID = index and self.maps[index].mapID or continentMaps[i];
			self.highestMapInfo.numQuests = numQuests;
			maxQuests = numQuests;
		end
	end
	self.maps = tFilter(self.maps, function(v) return v.numQuests > 0 end, true);
end

function OmegaMapBountyBoardMixin:FindBestMapForSelectedBounty()
	local currentMapID = GetCurrentMapAreaID();
	self:CacheWorldQuestDataForSelectedBounty();

	local candidateMapID;

	local maxQuests = 0;
	if (not self.currentCandidateIndex) then
		local hierarchy = GetMapHierarchy();
		for i, parentInfo in ipairs(hierarchy) do
			if (not parentInfo.isContinent) then
				ZoomOut();
				local myParentMap = FindInTableIf(self.maps, function(v) return v.mapID == parentInfo.id end);
				if (myParentMap) then
					self.currentCandidateIndex = myParentMap;
					break;
				end
			end
		end

		if (not self.currentCandidateIndex) then
			local myMap = FindInTableIf(self.maps, function(v) return v.mapID == currentMapID end);
			if (myMap) then
				self.currentCandidateIndex = myMap;
			end
		end

		if (not self.currentCandidateIndex) then
			self.currentCandidateIndex = FindInTableIf(self.maps, function(v) return v.mapID == self.highestMapInfo.mapID end);
		end
		candidateMapID = self.maps[self.currentCandidateIndex].mapID;
	elseif (#self.maps > 1) then
		self.currentCandidateIndex = self.currentCandidateIndex + 1;
		if (self.currentCandidateIndex > #self.maps) then
			self.currentCandidateIndex = 1;
		end
		candidateMapID = self.maps[self.currentCandidateIndex].mapID;
	else
		self.currentCandidateIndex = 1;
		candidateMapID = self.maps[1].mapID;
	end

	if ( candidateMapID and candidateMapID ~= currentMapID ) then
		SetMapByID(candidateMapID);
	end
end

function OmegaMapBountyBoardMixin:TryShowingIntroTutorial()
	if self.lockedType == OMEGA_MAP_BOUNTY_BOARD_LOCK_TYPE_NONE then
		if not self.TutorialBox:IsShown() and not GetCVarBitfield("closedInfoFrames", LE_FRAME_TUTORIAL_BOUNTY_INTRO) then
			self.TutorialBox.activeTutorial = LE_FRAME_TUTORIAL_BOUNTY_INTRO;

			self.TutorialBox.Text:SetText(BOUNTY_TUTORIAL_INTRO);

			if self:GetDisplayLocation() == LE_MAP_OVERLAY_DISPLAY_LOCATION_TOP_RIGHT or self:GetDisplayLocation() == LE_MAP_OVERLAY_DISPLAY_LOCATION_BOTTOM_RIGHT then
				SetClampedTextureRotation(self.TutorialBox.Arrow.Arrow, 270);
				SetClampedTextureRotation(self.TutorialBox.Arrow.Glow, 270);

				self.TutorialBox.Arrow:ClearAllPoints();
				self.TutorialBox.Arrow:SetPoint("TOPLEFT", self.TutorialBox, "TOPRIGHT", -4, -15);

				self.TutorialBox.Arrow.Glow:ClearAllPoints();
				self.TutorialBox.Arrow.Glow:SetPoint("CENTER", self.TutorialBox.Arrow.Arrow, "CENTER", 2, 0);

				self.TutorialBox:ClearAllPoints();
				self.TutorialBox:SetPoint("RIGHT", self, "LEFT", 10, -15);
			else
				SetClampedTextureRotation(self.TutorialBox.Arrow.Arrow, 90);
				SetClampedTextureRotation(self.TutorialBox.Arrow.Glow, 90);

				self.TutorialBox.Arrow:ClearAllPoints();
				self.TutorialBox.Arrow:SetPoint("TOPLEFT", self.TutorialBox, "TOPLEFT", -17, -15);

				self.TutorialBox.Arrow.Glow:ClearAllPoints();
				self.TutorialBox.Arrow.Glow:SetPoint("CENTER", self.TutorialBox.Arrow.Arrow, "CENTER", -3, 0);

				self.TutorialBox:ClearAllPoints();
				self.TutorialBox:SetPoint("LEFT", self, "RIGHT", -10, -15);
			end

			self.TutorialBox:Show();
		end
	end
end

function OmegaMapBountyBoardMixin:TryShowingCompletionTutorial()
	if self.lockedType == OMEGA_MAP_BOUNTY_BOARD_LOCK_TYPE_NONE and self.firstCompletedTab then
		if not self.TutorialBox:IsShown() and not GetCVarBitfield("closedInfoFrames", LE_FRAME_TUTORIAL_BOUNTY_FINISHED) then
			self.TutorialBox.activeTutorial = LE_FRAME_TUTORIAL_BOUNTY_FINISHED;

			self.TutorialBox.Text:SetText(BOUNTY_TUTORIAL_BOUNTY_FINISHED);

			SetClampedTextureRotation(self.TutorialBox.Arrow.Arrow, 0);
			SetClampedTextureRotation(self.TutorialBox.Arrow.Glow, 0);

			self.TutorialBox.Arrow:ClearAllPoints();
			self.TutorialBox.Arrow:SetPoint("TOP", self.TutorialBox, "BOTTOM", 0, 4);

			self.TutorialBox.Arrow.Glow:ClearAllPoints();
			self.TutorialBox.Arrow.Glow:SetPoint("TOP", self.TutorialBox.Arrow, "TOP", 0, 0);

			self.TutorialBox:ClearAllPoints();
			self.TutorialBox:SetPoint("BOTTOM", self.firstCompletedTab, "TOP", 0, 14);

			self.TutorialBox:Show();
		end
	end
end

function OmegaMapBountyBoardMixin:AreBountiesAvailable()
	return self:IsShown() and (self.lockedType == OMEGA_MAP_BOUNTY_BOARD_LOCK_TYPE_NONE or self.lockedType == OMEGA_MAP_BOUNTY_BOARD_LOCK_TYPE_NO_BOUNTIES);
end
