--	///////////////////////////////////////////////////////////////////////////////////////////

-- Code for TomTom  Integration 
-- Code is a modified version of TomTom_Waypoints.lua from TomTom (v60200-2.1.0)
-- TomTom is written by Cladhaire @ http://wow.curseforge.com/addons/tomtom/

--	///////////////////////////////////////////////////////////////////////////////////////////

if IsAddOnLoaded("TomTom") then
local OmegaMap = select(2, ...)

local L = TomTomLocals
local hbdp = LibStub("HereBeDragons-Pins-2.0")


-- Create a local table used as a frame pool
local pool = {}
local all_points = {}
local waypointMap = {}

end