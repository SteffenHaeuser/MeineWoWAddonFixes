local CdA = CreateFrame("frame")
CdA:RegisterEvent("ADDON_LOADED")
CdA:SetScript("OnEvent", function(self, event, name)
    if name == "CooldownAlpha" then
		
		local id, db
		if IsAddOnLoaded("Bartender4") then
			db = CooldownAlphaDB.BT4
		elseif IsAddOnLoaded("Dominos") then
			db = CooldownAlphaDB.Dominos
		else
			db = CooldownAlphaDB.Blizz
		end

		local CdStop = function(frame)
			frame:SetScript("OnUpdate", nil)
			frame:SetAlpha(db.RdyAlpha)
		end

		local CdUpdate = function(frame)
			if frame.StopTime < GetTime() then
				CdStop(frame)
			else
				frame:SetAlpha(db.CdAlpha)
			end
		end

		local CdStart = function(frame, id, name) 
			local start, duration
			if strfind(name, "Pet") ~= nil then
				start, duration = GetPetActionCooldown(id)
			else
				start, duration = GetActionCooldown(id)
			end
			frame.StopTime = start + duration
			frame:SetScript("OnUpdate", CdUpdate)
		end

		local GetCdId = function(frame, name, group)
			if IsAddOnLoaded("Bartender4") then
				if strfind(name, "Pet") ~= nil then
					id = db[group][name]
				elseif strfind(name, "Vehicle") ~= nil then
					id = ActionButton_GetPagedID(frame)
				else
					id = select(2, frame:GetAction())
				end
			else
				if strfind(name, "Pet") ~= nil then
					id = db[group][name]
				else
					id = ActionButton_GetPagedID(frame)
				end
			end
		end
		
		local GetGroup = function(name)
			for k, v in pairs(db) do
				if type(v) == "table" then
					for j, c in pairs(v) do
						if name == j then
							return k
						end
					end
				end
			end
		end
		
		local UpdateCd = function(cooldownFrame, _, duration)
			local frame = cooldownFrame:GetParent()
			local name = frame:GetName()
			local group = GetGroup(name)
			if not db[group] then
				return
			end
			GetCdId(frame, name, group)
			if frame:IsVisible() and duration == nil then
				frame:SetAlpha(db.RdyAlpha)
			elseif frame:IsVisible() and duration > 1.5 then
				CdStart(frame, id, name, group)
			else
				CdStop(frame)
			end
		end
		
		CdA:UnregisterEvent("ADDON_LOADED")
		
		local RefreshCd = function()
			if IsAddOnLoaded("Bartender4") then
				for k, v in pairs(db) do
					if type(v) == "table" then
						for j, c in pairs(v) do
							if not strfind(k, "Pet") then
								local _, duration = GetActionCooldown(c)
								if duration ~= 0 then
									_G[j]:SetAlpha(db.CdAlpha)
								else
									if not _G[j] then return end
									_G[j]:SetAlpha(db.RdyAlpha)
								end
							end
						end
					end
				end
			end
		end
		
		local CdA_Event = CreateFrame("frame")
		CdA_Event:RegisterEvent("ACTIONBAR_HIDEGRID")
		CdA_Event:SetScript("OnEvent", RefreshCd)
	end
end)