local Default = {
	["RdyAlpha"] = .3,
	["CdAlpha"] = 1,
}
local db, num, bar, mod
local name, addon = ...

local CdA_options = CreateFrame("frame", name, InterfaceOptionsFramePanelContainer)
CdA_options:RegisterEvent("ADDON_LOADED")
CdA_options:SetScript("OnEvent", function(self, event, name)
    if name == "CooldownAlpha" then
		
		if not CooldownAlphaDB then
			CooldownAlphaDB = {}
		end		
		local dbs = CooldownAlphaDB
		if IsAddOnLoaded("Bartender4") then
			num = {1, 13, 25, 37, 49, 61, 73, 85, 97, 109, 1, 1}
			bar = {"BT4Button", "BT4Button", "BT4Button", "BT4Button", "BT4Button", "BT4Button", "BT4Button", "BT4Button", "BT4Button", "BT4Button", "BT4PetButton", "VehicleMenuBarActionButton"}
			mod = "BT4"
			if dbs and not dbs.BT4 then
				dbs.BT4 = Default
				db = CooldownAlphaDB.BT4
			else
				db = CooldownAlphaDB.BT4
			end
		elseif IsAddOnLoaded("Dominos") then
			num = {1, 1, 1, 1, 1, 1, 13, 25, 37, 49, 1}
			bar = {"ActionButton", "DominosActionButton", "MultiBarRightButton", "MultiBarLeftButton", "MultiBarBottomRightButton", "MultiBarBottomLeftButton", "DominosActionButton", "DominosActionButton", "DominosActionButton", "DominosActionButton", "PetActionButton"}
			mod = "Dominos"
			if dbs and not dbs.Dominos then
				dbs.Dominos = Default
				db = CooldownAlphaDB.Dominos
			else
				db = CooldownAlphaDB.Dominos
			end
		else
			num = {1, 1, 1, 1, 1, 1, 1, 1}
			bar = {"ActionButton", "BonusActionButton", "MultiBarRightButton", "MultiBarLeftButton", "MultiBarBottomRightButton", "MultiBarBottomLeftButton", "PetActionButton", "VehicleMenuBarActionButton"}
			if dbs and not dbs.Blizz then
				dbs.Blizz = Default
				db = CooldownAlphaDB.Blizz
			else
				db = CooldownAlphaDB.Blizz
			end
		end
		
		CdA_options.name = name
		InterfaceOptions_AddCategory(CdA_options)
		
		local sliders = {}
		for i = 1, 2 do
			sliders[i] = CreateFrame("Slider", "sliders"..i, CdA_options, "OptionsSliderTemplate")
			sliders[i]:SetWidth(150)
			sliders[i]:SetHeight(15)
			sliders[i]:SetOrientation("HORIZONTAL")
			sliders[i]:SetMinMaxValues(0, 1)
			sliders[i]:SetValueStep(0.1)
			if i == 1 then
				sliders[i]:SetValue(db.CdAlpha)
				sliders[i]:SetPoint("TOPLEFT", 30, -30)
				_G[sliders[i]:GetName() .. "Low"]:SetText('0')
				_G[sliders[i]:GetName() .. "High"]:SetText('1')
				_G[sliders[i]:GetName() .. 'Text']:SetText('Cooldown Alpha')
			else
				sliders[i]:SetValue(db.RdyAlpha)
				sliders[i]:SetPoint("TOPRIGHT", -30, -30)
				_G[sliders[i]:GetName() .. "Low"]:SetText('0')
				_G[sliders[i]:GetName() .. "High"]:SetText('1')
				_G[sliders[i]:GetName() .. 'Text']:SetText('Ready Alpha')
			end
			sliders[i]:SetScript("OnValueChanged", function(self, value)
				local val = tonumber(string.format("%." .. (1) .. "f", value))
				for k, v in pairs(db) do
					if type(v) == "table" then
						for j, c in pairs(v) do
							local _, duration = GetActionCooldown(c) 
							if i == 1 then
								if duration > 0 then
									_G[j]:SetAlpha(val)
								end
								db.CdAlpha = val
							else
								if duration == 0 then
									_G[j]:SetAlpha(val)
								end
								db.RdyAlpha = val
							end
						end
					end
				end
			end)
		end
			
		local d
		for k in ipairs(bar) do
			d = k
		end
		
		local bnames = {}
		for i = 1, d do
			bnames[i] = CdA_options:CreateFontString(nil, "ARTWORK", "GameFontNormal")
			if i == 1 then
				if not mod then
					bnames[i]:SetPoint("TOPLEFT", 15, -68)
					bnames[i]:SetText(bar[i])
				else
					bnames[i]:SetPoint("TOPLEFT", 15, -68)
					bnames[i]:SetText(mod.." ".."Bar"..i)
				end
			elseif strfind(bar[i], "Pet") ~= nil then
				bnames[i]:SetPoint("TOPLEFT", bnames[i-1], 0, -30)
				bnames[i]:SetText("Pet".." ".."Bar")
			elseif strfind(bar[i], "Vehicle") ~= nil then
				bnames[i]:SetPoint("TOPLEFT", bnames[i-1], 0, -30)
				bnames[i]:SetText("Vehicle".." ".."Bar")
			else
				if not mod then
					bnames[i]:SetPoint("TOPLEFT", bnames[i-1], 0, -30)
					bnames[i]:SetText(bar[i])
				else
					bnames[i]:SetPoint("TOPLEFT", bnames[i-1], 0, -30)
					bnames[i]:SetText(mod.." ".."Bar"..i)
				end
			end
		end
				
		local checks = {}
		for i = 1, d do 
			checks[i] = CreateFrame("CheckButton", "checks"..i, CdA_options, "UICheckButtonTemplate")
			checks[i]:SetWidth(20)
			checks[i]:SetHeight(20)
			if i == 1 then
				checks[i]:SetPoint("TOPLEFT", CdA_options, 195, -65)
			else
				checks[i]:SetPoint("TOPLEFT", checks[i-1], 0, -30)
			end
			checks[i]:SetScript("OnClick", function()
				local n, nam
				
				if strfind(bar[i], "Pet") ~= nil then
					n = 9
					nam = "Pet"
				elseif strfind(bar[i], "Vehicle") ~= nil then
					n = 5
					nam = "Vehicle"
				else
					n = 11
					nam = "Bar"..i
				end
				if not db[nam] then
					db[nam] = {}
					for a = num[i], num[i] + n do
						db[nam][bar[i]..a] = a	
					end
				else
					db[nam] = nil
					for a = num[i], num[i] + n do
						if mod == "BT4" and not _G[bar[i]..a] then return end
						 if _G[bar[i]..a]~=nil then
						 if _G[bar[i]..a]:GetScript("OnUpdate") ~= nil then
							_G[bar[i]..a]:SetScript("OnUpdate", nil)
						 end
						 end
						if mod == "BT4" and not HasAction(a) then
							if not nam == "Pet" then
								_G[bar[i]..a]:SetAlpha(0)
							end
						else
						if _G[bar[i]..a] ~= nil then
							_G[bar[i]..a]:SetAlpha(db.CdAlpha)
							end
						end
					end
				end
				if checks[i]:GetChecked() ~= nil then
					for k, v in pairs(db) do
						if type(v) == "table" then
							for j, c in pairs(v) do
								if mod == "BT4" and not _G[j] then return end
								if not _G[j] then return end
								local id = ActionButton_GetPagedID(_G[j])
								local start, duration
								if strfind(j, "Pet") ~= nil then
									start, duration = GetPetActionCooldown(c)
								elseif mod == "BT4" and not strfind(j, "Vehicle") then
									start, duration = GetActionCooldown(c)
								else
									start, duration = GetActionCooldown(id)
								end
								if duration > 0 then
									_G[j]:SetAlpha(db.CdAlpha)
									_G[j]:SetScript("OnUpdate", function()
										if start + duration < GetTime() then
											_G[j]:SetAlpha(db.RdyAlpha)
											_G[j]:SetScript("OnUpdate", nil)
										else
											_G[j]:SetAlpha(db.CdAlpha)
										end
									end)
								else
									if mod == "BT4" and not HasAction(c) then
										if not nam == "Pet" then
											_G[j]:SetAlpha(0)
										end
									else
										_G[j]:SetAlpha(db.RdyAlpha)
									end
								end
							end
						end
					end
				end
			end)
		end
		CdA_options:SetScript("OnShow", function()
			for i = 1, #checks do
				if strfind(bar[i], "Pet") ~= nil then
					if db.Pet ~= nil then
						checks[i]:SetChecked()
					end
				elseif strfind(bar[i], "Vehicle") ~= nil then
					if db.Vehicle ~= nil then
						checks[i]:SetChecked()
					end
				else
					if db["Bar"..i] ~= nil then
						checks[i]:SetChecked()
					end
				end
			end
		end)
		CdA_options:UnregisterEvent("ADDON_LOADED")
	end
	SLASH_COOLDOWNALPHA1 = "/cda"
	SlashCmdList.COOLDOWNALPHA = function()
	InterfaceOptionsFrame_OpenToCategory(CdA_options)
	end
end)