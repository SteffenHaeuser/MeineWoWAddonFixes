TITAN_RELOADUI_ID = "ReloadUI";

function TitanPanelReloadUIButton_OnLoad(self)
	self.registry = {
		id = TITAN_RELOADUI_ID,
		menuText = TITAN_RELOADUI_MENU_TEXT, 
		category = "Interface",
		tooltipTitle = TITAN_RELOADUI_TOOLTIP, 
		tooltipTextFunction = "TitanPanelReloadUIButton_GetTooltipText", 
    icon = "Interface\\AddOns\\TitanReloadUI\\Artwork\\TitanReload",
		iconWidth = 16,
	};
end

function TitanPanelReloadUIButton_GetTooltipText()
	return ""..
		TitanUtils_GetGreenText(TITAN_RELOADUI_TOOLTIP_HINT1);
end

function TitanPanelReloadUIButton_OnClick(self, button)
		ReloadUI();
end

function TitanPanelRightClickMenu_PrepareReloadUIMenu()
	TitanPanelRightClickMenu_AddTitle(TitanPlugins[TITAN_RELOADUI_ID].menuText);
	TitanPanelRightClickMenu_AddCommand(TITAN_PANEL_MENU_HIDE, TITAN_RELOADUI_ID, TITAN_PANEL_MENU_FUNC_HIDE);
end
