TitanSUF = {}
local TS = TitanSUF

TS.id = "ShadowedUnitPlugin";
TS.addon = "TitanSUF";
TS.menu_text = "TitanSUF"
TS.tooltip_hint_1 = "Hint: Config's ShadowedUnitFrames"
TS.version = tostring(GetAddOnMetadata(TS.addon, "Version")) or "Unknown" 
TS.author = GetAddOnMetadata("TitanSUF", "Author") or "Unknown"

function TS.Button_OnLoad(self)
	local loaded, reason = LoadAddOn("ShadowedUF_Options")
	self.registry = {
		id = TS.id,
		version = TS.version,
		category = "Interface",
		menuText = TS.menu_text,
		buttonTextFunction = "TitanSUF_GetButtonText", 
		tooltipTitle = "ShadowedUnitFrames",
		tooltipTextFunction = "TitanSUF_GetTooltipText", 
		icon = "Interface\\AddOns\\TitanSUF\\SUF",
		iconWidth = 16,
		savedVariables = {
			ShowStarterNum = 1,
			ShowUsedSlots = false,			
			ShowIcon = 1,
			ShowLabelText = 1,
			ShowColoredText = 1,               
		}
	};     
end

function LockSUF(self)
	ShadowUF.db.profile.locked = not ShadowUF.db.profile.locked
	if ShadowUF.db.profile.locked == true then
		ShadowUF.modules.movers.isConfigModeSpec = true
	end
	ShadowUF.modules.movers:Update()
end


function TS.Button_OnClick(self, button)
	if (button == "LeftButton") then
		ShadowUF.Config:Open()
	elseif (button == "RightButton") then
		LockSUF(self)
	end
end

function TitanSUF_GetButtonText(id)
	return "SUF";
end

function TitanSUF_GetTooltipText()
	return "Config's Shadowed Unit Frames\n"
		..TitanUtils_GetGreenText(TS.tooltip_hint_1);
end


