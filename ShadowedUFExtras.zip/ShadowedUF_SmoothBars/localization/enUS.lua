-- Default locale
local SmoothBar = select(2, ...)
local L = {}

L["Enable SmoothBar"] = "Enable SmoothBar"
L["Enables smooth health and power bar animation"] = "Enables smooth health and power bar animation"

SmoothBar.L = L