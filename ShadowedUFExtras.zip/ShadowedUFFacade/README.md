# Masque Skinner: ShadowedUF
Masque Skinner: ShadowedUF skins Shadowed Unit Frames' buffs/debuffs with Masque. Each and every unit frame is individually customizable with any of the Masque skins that you know and love!

It is recommended that you set the button skin in ShadowedUnitFrames's options to "Blizzard" for ShadowedUF Facade to work optimally.