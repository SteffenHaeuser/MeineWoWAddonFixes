### 8.0.0 ###

- ToC to 80000.

### 7.3.0 ###

- ToC to 70300.

### 7.2.1 ###

- Added support for Equipped and Cooldown colors.
- Updated Masque_Version.
- Updated ReadMe.
- Updated Locales.

### 7.2.0 ###

- ToC to 70200.

### 7.1.0 ###

- ToC to 70100.

### 7.0.0 ###

- ToC to 70000.
- Renamed Autocast to Shine.
- Adjusted text positions.

### 6.2.2 ###

- Fixed links in Readme.
- Updated Changelog.

### 6.2.1 ###

- SVN to Git conversion.
- Added ChargeCooldown.
- Updated License and ReadMe.
- Updated .pkgmeta.

### 6.2.0 ###

- ToC to 60200.

### 6.1.0 ###

- ToC to 60100.

### 6.0.0 ###

- Added "No Shadow" version.
- ToC to 60000.

### 5.4.108 ###

- ToC to 50400.

### 5.3.106 ###

- ToC to 50300.

### 5.2.104 ###

- ToC to 50200.

### 5.1.102 ###

- ToC to 50100.

### 5.0.100 ###

- ToC to 50001.

### 4.3.98 ###

- ToC to 40300.

### 4.2.96 ###

- Renamed to Masque_Apathy.
- ToC to 40200.
- Updated to Masque's API.
- Updated locales.

### 4.0.80 ###

- Removed Border color.
- ToC to 40000.
- Code optimization.

### 3.3.75 ###

- ToC to 30300.
- Updated Locales.
- Updated License.

### 3.2.70 ###

- Added About.txt, Release.txt.
- ToC to 30200.
- Updated .pkgmeta.

### 3.1.66 ###

- Added X-WoWI-ID.
- Updated License.
- Updated X-Category.

### 3.1.64 ###

- ToC to 30100.

### 3.0.61 ###

- Fixed texture alphas.

### 3.0.58 ###

- Fixed the Border texture.

### 3.0.56 ###

- Fixed a typo.
- Fixed debuff coloring.

### 3.0.3.2 ###

- Added License.txt.
- Fixed ToC.

### 3.0.2.2 ###

- Adjusted Autocast.

### 3.0.2 ###

- ToC to 30000.
- Updated files.
