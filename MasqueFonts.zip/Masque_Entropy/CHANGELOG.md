### 8.0.0 ###

- ToC to 80000.

### 7.3.0 ###

- ToC to 70300.

### 7.2.1 ###

- Added support for Equipped and Cooldown colors.
- Updated Masque_Version.
- Updated ReadMe.
- Updated Locales.

### 7.2.0 ###

- ToC to 70200.

### 7.1.0 ###

- ToC to 70100.

### 7.0.0 ###

- ToC to 70000.
- Updated version.
- Renamed Autocast to Shine.
- Adjusted text positions.

### 6.2.2 ###

- Fixed links in Readme.

### 6.2.1 ###

- SVN to Git conversion.
- Added ChargeCooldown.
- Updated License and Readme.
- Updated .pkgmeta.

### 6.2.0 ###

- ToC to 60200.

### 6.1.0 ###

- ToC to 60100.

### 6.0.0 ###

- ToC to 60000.

### 5.4.83 ###

- ToC to 50400.

### 5.3.81 ###

- ToC to 50300.

### 5.2.79 ###

- ToC to 50200.

### 5.1.77 ###

- ToC to 50100.

### 5.0.75 ###

- ToC to 50001.

### 4.3.73 ###

- ToC to 40300.

### 4.2.71 ###

- Localization update.
- Renamed to Masque_Entropy.
- ToC to 40200.
- Updated to Masque's API.

### 4.0.62 ###

- Removed Border color.
- ToC to 40000.

### 3.3.57 ###

- Localization update.
- ToC to 30300.
- Updated License.

### 3.2.55 ###

- ToC to 30200.

### 3.1.49 ###

- Added X-WoWI-ID.
- Updated X-Category.
- Updated License.

### 3.1.46 ###

- ToC to 30100.

### 3.0.43 ###

- Fixed a typo.
- Adjusted version.
- Fixed debuff coloring.
- Texture tweaks.

### 3.0.3.2 ###

- Added License.txt.

### 3.0.2.2 ###

- Adjusted Autocast.

### 3.0.2 ###

- ToC to 30100.
