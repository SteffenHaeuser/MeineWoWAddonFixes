### 8.0.0 ###

- ToC to 80000.

### 7.3.0 ###

- ToC to 70300.

### 7.2.1 ###

- Added support for Equipped and Cooldown colors.
- Updated Masque_Version.
- Updated ReadMe.
- Updated Locales.

### 7.2.0 ###

- ToC to 70200.

### 7.1.0 ###

- ToC to 70100.

### 7.0.0 ###

- ToC to 70000.
- Renamed Autocast to Shine.
- Adjusted text positions.

### 6.2.2 ###

- Fixed links in Readme.

### 6.2.1 ###

- SVN to Git conversion.
- Added ChargeCooldown.
- Updated License and ReadMe.
- Updated .pkgmeta.
- Updated Locales.

### 6.2.0 ###

- ToC to 60200.

### 6.1.0 ###

- ToC to 60100.

### 6.0.0 ###

- Added "No Shadow" version.
- ToC to 60000.
- Updated Locales.

### 5.4.88 ###

- ToC to 50400.

### 5.3.86 ###

- ToC to 50300.

### 5.2.84 ###

- ToC to 50200.

### 5.1.82 ###

- ToC to 50100.

### 5.0.80 ###

- ToC to 50001.

### 4.3.78 ###

- ToC to 40300.

### 4.2.76 ###

- Renamed to Masque_Caith.
- ToC to 40200.
- Updated to Masque's API.
- Updated Locales.

### 4.0.62 ###

- ToC to 40000.
- Removed Border color.
- Code optimization.

### 3.3.57 ###

- ToC to 30300.
- Updated Locales.
- Updated License.

### 3.2.55 ###

- Add About.txt.
- ToC to 30200.
- Updated .pkgmeta.

### 3.1.50 ###

- Add X-WoWI-ID.
- Updated License.
- Updated X-Category.

### 3.1.47 ###

- ToC to 30100.

### 3.0.44 ###

- Fixed texture alphas.

### 3.0.42 ###

- Fixed a typo.
- Fixed debuff coloring.

### 3.0.3.2 ###

- Added License.txt.
- Fixed ToC.

### 3.0.2.2 ###

- Adjusted Autocast.

### 3.0.2 ###

- ToC to 30000.
- Updated files.
