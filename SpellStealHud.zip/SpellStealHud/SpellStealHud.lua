
local SpellStealHud_LastUpdate = 0

local t = UIParent:CreateFontString()
t:SetFont("Fonts\\FRIZQT__.TTF", 24, "OUTLINE, MONOCHROME")
t:SetPoint("CENTER")

local t2 = UIParent:CreateFontString()
t2:SetFont("Fonts\\FRIZQT__.TTF", 24, "OUTLINE, MONOCHROME")
t2:SetPoint("BOTTOM", t, "TOP")
t2:SetTextColor(1, 0, 0)

local t3 = UIParent:CreateFontString()
t3:SetFont("Fonts\\FRIZQT__.TTF", 24, "OUTLINE, MONOCHROME")
t3:SetPoint("TOP", t, "BOTTOM")
t3:SetTextColor(1, 0, 0)

local t4 = UIParent:CreateFontString()
t4:SetFont("Fonts\\FRIZQT__.TTF", 24, "OUTLINE, MONOCHROME")
t4:SetPoint("TOP", t3, "BOTTOM")
t4:SetTextColor(1, 0, 0)

local function SpellStealHudFrame_CheckCasting()
  local s = UnitCastingInfo("target")

    for i = 1, GetNumGroupMembers() do
    for j = 1, 40 do
     auraname = UnitAura("raid"..i, i, "HARMFUL") 
     if (auraname) then
        if auraname == "Frostbite" then
	         t2:SetFormattedText("*** PLAYER WITH FROSTBITE!!!!!! ***")
           PlaySoundFile("Interface\\AddOns\\SpellStealHud\\Media\\steal2.mp3")   
        end
      end
    end
   end

  for i = 1, 40 do
   local name, rank, icon, count, debuffType, duration, expirationTime, unitCaster, isStealable,name2,rank2,icon2,count2,debuffType2,dur2,exp2,un2,is2;    

   name = UnitAura("player",i)

   name2, rank2, icon2, count2, debuffType2, dur2, exp2, un2, is2  = UnitAura("player", i, "HELPFUL") 
   if name2 then
    if (name2 == "Innervate") then
        t2:SetFormattedText("**** ANREGEN ON YOU!!!!!!!!!!! ***")
    end

    if (name2 == "Frostbite") then
        t2:SetFormattedText("*** FROSTBITE!!!! ***")
        PlaySoundFile("Interface\\Addons\\SpellStealHud\\Media\\steal.mp3")
    end
   
    if (name2 == "Cauterize") then
      t2:SetFormattedText("**** CAUTERIZE ON YOU !!!!! ****")
      PlaySoundFile("Interface\\Addons\\SpellStealHud\\Media\\steal2.mp3")
    end
   end

   name, rank, icon, count, debuffType, duration, expirationTime, unitCaster, isStealable  = UnitAura("player", i, "HARMFUL") 

   local handled = false

   if (name) then

    if (name == "Cauterize") then
      t2:SetFormattedText("**** CAUTERIZE ON YOU !!!!! ****")
      PlaySoundFile("Interface\\Addons\\SpellStealHud\\Media\\steal2.mp3")
    end

    if (name == "Frostbite") then
       PlaySoundFile("Interface\\Addons\\SpellStealHud\\Media\\steal2.mp3")
       t2:SetFormattedText("*** FROSTBITE ON YOU !!!!!!!!!!! ***")
    end  

    if (handled==false) then
        t2:SetFormattedText(strjoin("*** A HARMFUL AURA WAS FOUND ON YOU --- ",name));
        handled = false;
    end

   end

  end
  
   for i = 1, GetNumGroupMembers() do
 --  if UnitName("raid"..i.."target") == "Blood of the Old God" then
 --   t2:SetFormattedText("*** ADDS!!!! ADDS!!!! ADDS!!!! ***")
 --   PlaySoundFile("Interface\\AddOns\\SpellStealHud\\Media\\steal2.mp3")
   end



 -- if UnitExists("Blood of the Old God") then
 --   t2:SetFormattedText("*** ADDS!!!! ADDS!!!! ADDS!!!! ***")
 --   PlaySoundFile("Interface\\AddOns\\SpellStealHud\\Media\\steal2.mp3")
 -- end 
  
  if s then
    t2:SetFormattedText("*** CASTING *** --- %s", s)
  else
    s = UnitChannelInfo("target")

    if s then
      t2:SetFormattedText("*** CHANNELING *** --- %s", s)
    else
      t2:SetText("")
    end
  end
end

local function SpellStealHudFrame_CheckDebuffs()
  
  if (not UnitCanAttack("player", "target")) then
    t3:SetText("")
    return
  end

  local i = 1
  local buffs = "*** SPELLSTEAL *** "
  local n, _, _, c, _, _, t, m, s = UnitBuff("target", i)

  while n do
    if s then
      buffs = strjoin(" --- ", buffs, n)
    end

    i = i + 1
    n, _, _, c, _, _, t, m, s = UnitBuff("target", i)
  end

  if buffs == "*** SPELLSTEAL *** " then
    t2:SetText("")
  else
    t2:SetText(buffs)
    UIErrorsFrame:AddMessage(buffs, 1.0, 0.0, 0.0, nil, 5);
    PlaySoundFile("Interface\\AddOns\\SpellStealHud\\Media\\steal.mp3")
  end
end

local function SpellStealHudFrame_CheckDebuffs2()
  
  if (not UnitCanAttack("player", "focus")) then
    t3:SetText("")
    return
  end

  local i = 1
  local buffs = "*** SPELLSTEAL FOCUS *** "
  local n, _, _, c, _, _, t, m, s = UnitBuff("focus", i)

  while n do
    if s then
      buffs = strjoin(" --- ", buffs, n)
    end

    i = i + 1
    n, _, _, c, _, _, t, m, s = UnitBuff("focus", i)
  end

  if buffs == "*** SPELLSTEAL FOCUS *** " then
    t2:SetText("")
  else
    t2:SetText(buffs)
    UIErrorsFrame:AddMessage(buffs, 1.0, 0.0, 0.0, nil, 5);
    PlaySoundFile("Interface\\AddOns\\SpellStealHud\\Media\\steal2.mp3")
  end
end

local function SpellStealHudFrame_UpdateText() 
    t:SetText("")
end

local f = CreateFrame("Frame")

if select(2, UnitClass("player")) == "MAGE" then
  f:SetScript("OnUpdate",
    function()
      if (GetTime() - SpellStealHud_LastUpdate) > 0.2 then
        SpellStealHud_LastUpdate = GetTime()
        SpellStealHudFrame_CheckCasting()
        SpellStealHudFrame_CheckDebuffs()
        SpellStealHudFrame_CheckDebuffs2()
        SpellStealHudFrame_UpdateText()
      end
    end
  )

  f:RegisterEvent("PLAYER_TALENT_UPDATE")

else
  f:SetScript("OnUpdate",
    function()
      if (GetTime() - SpellStealHud_LastUpdate) > 0.2 then
        SpellStealHud_LastUpdate = GetTime()
        SpellStealHudFrame_CheckCasting()
      end
    end
  )
end
