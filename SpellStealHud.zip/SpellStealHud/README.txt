===============================================
SpellStealHud 5.1 by Kloo @ Malygos, Melliandra
===============================================

This tiny addon is a modification of Kloo's AlarmHUDmage to only show the SpellSteal message,
not the other messages, for mages who use other Addons to track HotStreak etc., but who still
want a SpellSteal Addon. It will also still remind of the target casting/channeling, though.


ChangeLog:

1.0 - Initial release.
